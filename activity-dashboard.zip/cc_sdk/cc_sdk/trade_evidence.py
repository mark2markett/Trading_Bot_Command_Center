"""Point-in-time trading evidence, stored alongside existing decisions, never orders."""
from __future__ import annotations

import math
from uuid import uuid4

PHASES = {'candidate', 'selection', 'risk_rejected', 'passed', 'entry', 'observation', 'exit', 'exit_blocked'}
FIELDS = {
    'underlying_price', 'signal', 'side', 'stop', 'target', 'reason', 'books', 'occ', 'bid', 'ask',
    'quote_time', 'delta', 'theta', 'iv', 'oi', 'volume', 'expiry', 'strike', 'right', 'source',
    'qty', 'net_debit', 'max_loss_usd', 'max_payoff_usd', 'premium_cap_usd', 'risk_budget_usd',
    'order_ids', 'trade_id', 'risk_ok', 'risk_reason', 'fill_prices', 'entry_cost_usd',
    'liquidation_value_usd', 'quote_status', 'dte', 'exit_reason', 'close_method', 'realized_pnl',
    'entry_policy', 'correlation_coverage', 'pnl_basis',
}


def clean(value, depth=0):
    if depth > 5:
        return None
    if isinstance(value, dict):
        return {key: clean(item, depth + 1) for key, item in value.items() if key in FIELDS}
    if isinstance(value, (list, tuple)):
        return [clean(item, depth + 1) for item in value[:20]]
    if type(value) is float:
        return value if math.isfinite(value) else None
    if value is None or type(value) in (int, bool):
        return value
    return str(value)[:300]


def record(bot, phase, symbol, *, candidate_id=None, details=None):
    if phase not in PHASES:
        raise ValueError('Unsupported evidence phase')
    candidate_id = candidate_id or uuid4().hex
    bot.L.decision(bot.m.id, 'session', {
        'schema_version': 1, 'candidate_id': candidate_id, 'phase': phase, 'symbol': symbol,
        'rule_version': bot.m.version,
        'execution_origin': 'local_paper_simulation' if bot.m.mode == 'paper' else 'broker_unverified',
        'details': clean(details or {}),
    }, 'TRADE_EVIDENCE', phase)
    return candidate_id


def book(quote):
    return {name: getattr(quote, name) for name in (
        'occ', 'bid', 'ask', 'quote_time', 'delta', 'theta', 'iv', 'oi', 'volume', 'strike', 'right'
    )} | {'expiry': quote.expiry.isoformat()}
