"""Read-only account marks: Schwab equities, Polygon option books. No orders or fallback feeds."""
from __future__ import annotations

import math
import time

from cc_sdk.options import is_occ, parse_occ
from cc_sdk.schwab_feed import QuoteDataError


class AccountQuotes:
    def __init__(self, schwab, polygon=None):
        self.schwab = schwab
        self.polygon = polygon

    def account_quote(self, symbol: str) -> tuple[float, float]:
        if not is_occ(symbol):
            return self.schwab.account_quote(symbol)
        if self.polygon is None:
            from cc_sdk.polygon_options import polygon_from_env

            self.polygon = polygon_from_env()
        root, expiry, right, strike = parse_occ(symbol)
        quotes = self.polygon.snapshot(root, expiry, expiry, strike_gte=strike, strike_lte=strike)
        matches = [q for q in quotes if parse_occ(q.occ) == (root, expiry, right, strike)]
        if len(matches) != 1:
            raise QuoteDataError("Polygon account contract missing or ambiguous")
        quote = matches[0]
        age = time.time() - quote.quote_time
        if (not all(math.isfinite(value) for value in (quote.bid, quote.ask, quote.quote_time))
                or quote.bid < 0 or quote.ask <= 0 or quote.ask < quote.bid
                or quote.quote_time <= 0 or not 0 <= age <= 90):
            raise QuoteDataError("Polygon account book or timestamp unavailable, invalid or stale")
        return quote.mid, age
