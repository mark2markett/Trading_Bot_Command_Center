"""Read-only activity and recorded P&L from one consistent ledger snapshot.

Orders, holdings and closed trades are distinct records. No strategy, broker,
valuation refresh, schema migration or trading write belongs in this module.
"""
from __future__ import annotations

import json
import math
from datetime import date, datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from cc_sdk.control import Control, control_dir
from cc_sdk.options import contract_multiplier, is_occ, parse_occ

ET = ZoneInfo('America/New_York')
WORKING = {'sent', 'submitted', 'pending', 'open', 'new', 'accepted', 'partially_filled', 'pending_cancel', 'pending_replace'}
TERMINAL = {'filled', 'cancelled', 'canceled', 'rejected', 'expired', 'failed', 'done'}
PAGE_SIZE = 50
SHARE_STRATEGIES = {'spy_mr', 'gap_go', 'nr7', 'sip_orb'}


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def total(values):
    values = list(values)
    return round(sum(values), 2) if all(number(v) for v in values) else None


def session_day(value):
    try:
        if len(value) == 10:
            return date.fromisoformat(value)
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return stamp.astimezone(ET).date() if stamp.tzinfo else None
    except (TypeError, ValueError, AttributeError):
        return None


def marked_position(p, mark, invalid, now):
    result = dict(p)
    result.update(kind='option_leg' if is_occ(p['symbol']) else 'shares', mark_price=None, mark_at=None,
                  mark_status='missing', entry_cost=None, current_value=None, open_pnl=None)
    if number(p['avg_price']) and p['avg_price'] > 0:
        result['entry_cost'] = p['qty'] * p['avg_price'] * contract_multiplier(p['symbol'])
    if mark:
        result['mark_at'] = mark['at']
        try:
            stamp = datetime.fromisoformat(mark['at'].replace('Z', '+00:00'))
            age = (now - stamp).total_seconds() if stamp.tzinfo else -1
        except (TypeError, ValueError, AttributeError):
            age = -1
        result['mark_status'] = 'invalid' if not number(mark['price']) or mark['price'] <= 0 or age < 0 else 'stale' if age > 60 else 'current'
        if p['symbol'] in invalid:
            result['mark_status'] = 'invalid'
        if result['mark_status'] == 'current':
            result['mark_price'] = mark['price']
            result['current_value'] = p['qty'] * mark['price'] * contract_multiplier(p['symbol'])
            if result['entry_cost'] is not None:
                result['open_pnl'] = round(result['current_value'] - result['entry_cost'], 2)
    if is_occ(p['symbol']):
        try:
            root, expiry, right, strike = parse_occ(p['symbol'])
            result.update(underlying=root, expiry=expiry.isoformat(), right=right, strike=strike)
        except ValueError:
            result.update(kind='unverified_option', mark_status='invalid', open_pnl=None)
    result['side'] = 'Long' if p['qty'] > 0 else 'Short'
    return result


def position_groups(bot, positions, option_metadata):
    remaining = {p['symbol']: p for p in positions}
    groups = []
    for record in option_metadata:
        legs = record.get('legs', [])
        if not isinstance(legs, list) or len(legs) != 2 or not all(isinstance(s, str) and s in remaining for s in legs) or len(set(legs)) != 2:
            continue
        long, short = (remaining[s] for s in legs)
        if not all(p['kind'] == 'option_leg' for p in (long, short)) or long['qty'] <= 0 or short['qty'] != -long['qty'] or record.get('qty') != long['qty']:
            continue
        if any(long.get(k) != short.get(k) for k in ('underlying', 'expiry', 'right')):
            continue
        current = all(p['mark_status'] == 'current' for p in (long, short))
        group = {'id': bot['id'] + ':' + ':'.join(legs), 'bot_id': bot['id'], 'bot_name': bot['name'],
                 'kind': 'spread', 'symbol': long['underlying'], 'quantity': long['qty'], 'unit': 'spreads',
                 'label': f"{long['underlying']} {'call' if long['right'] == 'C' else 'put'} spread {long['strike']:g}/{short['strike']:g}",
                 'expiry': long['expiry'], 'side': 'Debit spread', 'legs': [long, short],
                 'entry_cost': total(p['entry_cost'] for p in (long, short)),
                 'current_value': total(p['current_value'] for p in (long, short)),
                 'open_pnl': total(p['open_pnl'] for p in (long, short)),
                 'mark_at': min((p['mark_at'] for p in (long, short)), key=lambda stamp: datetime.fromisoformat(stamp.replace('Z', '+00:00'))) if current else None,
                 'mark_status': 'current' if current else 'unavailable'}
        groups.append(group)
        for leg in legs:
            del remaining[leg]
    for p in remaining.values():
        label = p['symbol'] if p['kind'] in ('shares', 'unverified_option') else f"{p['underlying']} {p['strike']:g} {'call' if p['right'] == 'C' else 'put'}"
        groups.append({'id': bot['id'] + ':' + p['symbol'], 'bot_id': bot['id'], 'bot_name': bot['name'],
                       'kind': p['kind'], 'symbol': p['symbol'], 'label': label, 'quantity': abs(p['qty']),
                       'unit': 'shares' if p['kind'] == 'shares' else 'contracts', 'side': p['side'],
                       'expiry': p.get('expiry'), 'legs': [p], **{k: p[k] for k in ('entry_cost', 'current_value', 'open_pnl', 'mark_at', 'mark_status')}})
    return groups


def entry_control(folder, bot):
    if not folder.is_dir():
        return 'blocked', 'Control directory unavailable'
    if (folder / 'KILL').exists() or (folder / (bot + '.kill')).exists():
        return 'blocked', 'Kill control active'
    if (folder / (bot + '.flatten')).exists():
        return 'blocked', 'Exit requested'
    shares_blocked = bot in SHARE_STRATEGIES and Control(bot, folder).options_only()
    pause = folder / 'PAUSE_ENTRIES' if (folder / 'PAUSE_ENTRIES').exists() else folder / (bot + '.pause')
    if pause.exists():
        try:
            reason = json.loads(pause.read_text()).get('reason') or 'Entries paused'
        except (OSError, ValueError, AttributeError):
            reason = 'Entries paused'
        return 'paused', (('Options-only: share strategy disabled. ' if shares_blocked else '') + str(reason))[:200]
    if shares_blocked:
        return 'blocked', 'Options-only trading: this share strategy cannot open new positions'
    return 'clear', 'Entry controls clear; signals, data and risk checks still apply'


def snapshot(L, *, now=None, controls=None, order_offset=0, trade_offset=0):
    now = now or datetime.now(timezone.utc)
    controls = Path(controls) if controls is not None else control_dir()
    with L.transaction(write=False):
        bots = [dict(r) for r in L.q('SELECT id,name,mode,instrument,status FROM bots ORDER BY name')]
        positions = [dict(r) for r in L.q('SELECT * FROM positions WHERE qty<>0 ORDER BY bot_id,symbol')]
        orders = [dict(r) for r in L.q('SELECT * FROM orders ORDER BY id DESC')]
        filled = {r['order_id']: r['filled_qty'] for r in L.q('SELECT order_id,SUM(ABS(qty)) filled_qty FROM fills GROUP BY order_id')}
        trades = [dict(r) for r in L.q('SELECT * FROM trades ORDER BY exit_at DESC,id DESC')]
        marks = {r['symbol']: dict(r) for r in L.q('SELECT * FROM paper_marks')}
        settings = {r['key']: r['value_json'] for r in L.q('SELECT key,value_json FROM kv')}
        option_trades = {}
        for r in L.q('SELECT * FROM option_trades'):
            option_trades.setdefault((r['bot_id'], r['trade_id']), []).append(dict(r))
        heartbeats = [dict(r) for r in L.q('SELECT h.* FROM heartbeats h JOIN (SELECT bot_id,MAX(id) id FROM heartbeats GROUP BY bot_id) latest ON h.id=latest.id')]
        invalid = {key.split(':', 1)[1] for key in settings if key.startswith('paper_mark_invalid:')}
        registered = {b['id'] for b in bots}
        orphan_ids = {r['bot_id'] for r in positions + orders + trades if r['bot_id'] not in registered}
        for bot in sorted(orphan_ids, key=str):
            bots.append({'id': bot, 'name': 'Unregistered bot: ' + str(bot), 'mode': 'unknown', 'instrument': '', 'status': 'unknown'})
        output_bots, groups = [], []
        names = {b['id']: b['name'] for b in bots}
        mode = {b['id']: b['mode'] for b in bots}
        for order in orders:
            order['bot_name'] = names[order['bot_id']]
            order['mode'] = mode[order['bot_id']]
            status = str(order['status']).lower()
            order['status_class'] = 'working' if status in WORKING else 'terminal' if status in TERMINAL else 'unknown'
            order['filled_qty'] = filled.get(order['id'], 0)
            order['remaining_qty'] = max(0, abs(order['qty']) - order['filled_qty'])
            order['protection'] = 'paper_daily_bar' if order['mode'] == 'paper' and order['bot_id'] == 'spy_mr' and order['type'] == 'STOP' else 'paper_order' if order['mode'] == 'paper' else 'broker_unverified'
        working = [o for o in orders if o['status_class'] != 'terminal']
        history = [o for o in orders if o['status_class'] == 'terminal']
        for trade in trades:
            trade['bot_name'] = names[trade['bot_id']]
            trade['pnl'] = trade['pnl'] if number(trade['pnl']) else None
            meta = option_trades.get((trade['bot_id'], trade['id']), [])
            bot = next(b for b in bots if b['id'] == trade['bot_id'])
            trade['instrument'] = meta[0]['underlying'] + ' spread' if len(meta) == 1 else bot['instrument'] if bot['instrument'] and ',' not in bot['instrument'] and bot['instrument'] != 'scanner' else 'Symbol not recorded'
        today = now.astimezone(ET).date()
        for bot in bots:
            ps = [marked_position(p, marks.get(p['symbol']) if bot['mode'] == 'paper' else None, invalid, now) for p in positions if p['bot_id'] == bot['id']]
            metadata = []
            for key, value in settings.items():
                if key.startswith('optlive:' + str(bot['id']) + ':'):
                    try:
                        record = json.loads(value)
                        if isinstance(record, dict):
                            metadata.append(record)
                    except (TypeError, ValueError):
                        pass
            owned = position_groups(bot, ps, metadata)
            groups.extend(owned)
            closed = [t for t in trades if t['bot_id'] == bot['id']]
            day_valid = all(session_day(t['exit_at']) is not None for t in closed)
            state, reason = entry_control(controls, str(bot['id']))
            if bot['mode'] == 'unknown':
                state, reason = 'blocked', 'Bot registration unavailable'
            output_bots.append({'id': bot['id'], 'name': bot['name'], 'mode': bot['mode'], 'run_status': bot['status'],
                                'entry_state': state, 'entry_reason': reason,
                                'open_positions': len(owned), 'working_orders': sum(o['bot_id'] == bot['id'] and o['status_class'] == 'working' for o in working),
                                'unverified_orders': sum(o['bot_id'] == bot['id'] and o['status_class'] == 'unknown' for o in working),
                                'open_pnl': total(p['open_pnl'] for p in owned), 'closed_pnl': total(t['pnl'] for t in closed),
                                'closed_pnl_today': total(t['pnl'] for t in closed if session_day(t['exit_at']) == today) if day_valid else None,
                                'closed_trades': len(closed), 'last_run': next((h for h in heartbeats if h['bot_id'] == bot['id']), None)})
        closed_pnl = total(t['pnl'] for t in trades)
        open_pnl = total(p['open_pnl'] for p in groups)
        return {'as_of': now.isoformat(), 'quote_max_age_seconds': 60, 'page_size': PAGE_SIZE,
                'entry_policy': {'options_only': Control('', controls).options_only(),
                                 'legacy_share_positions': sum(p['kind'] == 'shares' for p in groups)},
                'summary': {'open_positions': len(groups), 'position_legs': len(positions), 'working_orders': sum(o['status_class'] == 'working' for o in working),
                            'unverified_orders': sum(o['status_class'] == 'unknown' for o in working),
                            'closed_trades': len(trades), 'order_history_total': len(history),
                            'closed_pnl': closed_pnl, 'open_pnl': open_pnl,
                            'total_pnl': total([closed_pnl, open_pnl]),
                            'closed_pnl_today': total(b['closed_pnl_today'] for b in output_bots)},
                'bots': output_bots, 'positions': groups, 'working_orders': working,
                'order_history': history[order_offset:order_offset + PAGE_SIZE], 'order_offset': order_offset,
                'closed_trades': trades[trade_offset:trade_offset + PAGE_SIZE], 'trade_offset': trade_offset,
                'pnl_basis': 'Recorded closed-trade P&L plus fresh marked open P&L. Fees may be excluded from older trade records.'}
