"""Read-only runtime observations. No bot commands, credential contents or trading writes."""

from __future__ import annotations

import json
import sqlite3
import time
import urllib.request
from contextlib import closing
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from .classify import classify_alert
from .models import BOT_IDS, Observation, iso, parsed

ET = ZoneInfo("America/New_York")


def readonly(path):
    path = Path(path).resolve(strict=True)
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=1)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA query_only=ON")
    return db


def identity(path):
    p = Path(path).resolve(strict=True)
    stat = p.stat()
    if not stat.st_ino:
        raise ValueError("Ledger identity unavailable")
    return f"{p}:{stat.st_dev}:{stat.st_ino}"


def read_alert_page(ledger_path, after_id, limit=250):
    tag = identity(ledger_path)
    with closing(readonly(ledger_path)) as db:
        rows = [
            dict(r)
            for r in db.execute(
                "SELECT id,at,kind,bot_id,severity,acknowledged_at FROM alerts WHERE id>? ORDER BY id LIMIT ?",
                (after_id, min(1000, max(1, limit))),
            )
        ]
    if identity(ledger_path) != tag:
        raise ValueError("Ledger changed during read")
    return tag, rows, rows[-1]["id"] if rows else after_id


def ingest_alerts(path, store, now, page_limit=250):
    tag = identity(path)
    with closing(readonly(path)) as db:
        maximum = db.execute("SELECT COALESCE(max(id),0) FROM alerts").fetchone()[0]
    previous = store.state("ledger_identity")
    cursor = store.state("alert_cursor", 0)
    if previous and (previous != tag or maximum < cursor):
        # A generation also distinguishes an in-place restore with reused IDs.
        generation = store.state("generation", 0) + 1
        with store.transaction():
            store.set_state("generation", generation)
            store.set_state("alert_cursor", 0)
            store.set_state("bootstrap_max_id", maximum)
            store.set_state("continuity_ok", False)
            store.set_state("coherent_ticks", 0)
            store._observe(Observation("ledger_changed", "fleet", None, "page", "unknown", iso(now), {}), "reset")
        cursor = 0
    if store.state("bootstrap_max_id") is None:
        store.set_state("bootstrap_max_id", maximum)
        store.set_state("continuity_ok", False)
    tag, rows, end = read_alert_page(path, cursor, page_limit)
    observations = [
        classify_alert(r, historical=r["id"] <= store.state("bootstrap_max_id"))
        for r in rows
        if r["id"] > store.state("bootstrap_max_id") or not r["acknowledged_at"]
    ]
    store.ingest_page(observations, end, tag, now)
    for r in rows:
        if r["acknowledged_at"]:
            store.acknowledge_source(r["id"], r["acknowledged_at"])
    return len(rows) == page_limit


def refresh_source_acknowledgments(ledger_path, store, deadline):
    ids = [
        r[0]
        for r in store.conn.execute(
            "SELECT alert_id FROM incident_sources WHERE ledger_id=? ORDER BY alert_id", (store.source_identity(),)
        )
    ]
    with closing(readonly(ledger_path)) as db:
        for start in range(0, len(ids), 250):
            if time.monotonic() >= deadline:
                break
            batch = ids[start : start + 250]
            for row in db.execute(
                "SELECT id,acknowledged_at FROM alerts WHERE id IN (" + ",".join("?" for _ in batch) + ")", batch
            ):
                if row["acknowledged_at"]:
                    store.acknowledge_source(row["id"], row["acknowledged_at"])


def fetch_json(url, deadline, monotonic=time.monotonic, sleep=time.sleep):
    for attempt, delay in enumerate((0, 2, 5)):
        if monotonic() + delay + 1 >= deadline:
            raise TimeoutError("Observation deadline")
        if delay:
            sleep(delay)
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "CC-incident-monitor/1"})
            with urllib.request.urlopen(request, timeout=min(5, deadline - monotonic())) as response:
                if response.status != 200:
                    raise ValueError("Unexpected status")
                payload = json.loads(response.read(262145))
                if not isinstance(payload, dict):
                    raise ValueError("Unexpected response")
                return payload
        except (OSError, ValueError):
            if attempt == 2:
                raise
    raise TimeoutError("Observation deadline")


def collect_observations(repo, *, now, deadline):
    from cc_sdk.ledger import var_dir

    from cc_server import calendar, position_monitor, riskd

    runtime = var_dir()
    at = iso(now)
    session = now.astimezone(ET).date().isoformat()
    output = []
    with closing(readonly(runtime / "cc.db")) as db:
        db.execute("BEGIN")
        bots = [dict(row) for row in db.execute("SELECT id,mode FROM bots")]
        saved = db.execute("SELECT value_json FROM kv WHERE key=?", (position_monitor.KEY,)).fetchone()
        try:
            reports = json.loads(saved[0]) if saved else {}
        except (ValueError, TypeError):
            reports = {}
        if not isinstance(reports, dict):
            reports = {}
        for bot in bots:
            positions = [dict(p) for p in db.execute("SELECT * FROM positions WHERE bot_id=? AND qty<>0", (bot['id'],))]
            checked = position_monitor.inspect_report(reports.get(bot['id']), positions, now)
            if not positions and bot['id'] not in reports:
                continue
            good = checked['status'] == 'current' and not checked['issues'] and all(p['quote_status'] == 'current' for p in checked['positions'])
            verdict = 'healthy' if good else 'failing' if checked['status'] == 'review' else 'unknown'
            output.append(Observation('position_mismatch', bot['id'], session, 'digest', verdict, at,
                                      {'checked_at': checked['checked_at'], 'issues': checked['issues'], 'status': checked['status']}))
        paper = {b["id"] for b in bots} == BOT_IDS and all(b["mode"] == "paper" for b in bots)
        output.append(Observation("paper_fleet", "fleet", None, "page", "healthy" if paper else "failing", at, {"paper": paper}))
        close = 780 if calendar.is_early_close(now.astimezone(ET).date()) else 960
        minute = now.astimezone(ET).hour * 60 + now.astimezone(ET).minute
        trading = calendar.is_trading_day(now.astimezone(ET).date())
        if not 2025 <= now.year <= 2027:
            raise ValueError("Calendar coverage unavailable")
        start = now.astimezone(ET).replace(hour=0, minute=0, second=0, microsecond=0)
        lo, hi = iso(start), iso(start + timedelta(days=1))
        if trading:
            for bot in sorted(BOT_IDS):
                runs = [("session", 575)] if bot != "spy_mr" else [("reconcile", 585), ("decide", close - 10)]
                for run, due in runs:
                    active = (due <= minute < close) if run == "session" else minute >= due + 10
                    if not active:
                        continue
                    row = db.execute(
                        "SELECT at,ok,detail FROM heartbeats WHERE bot_id=? AND run=? AND at>=? AND at<? ORDER BY id DESC LIMIT 1",
                        (bot, run, lo, hi),
                    ).fetchone()
                    due_at = start.replace(hour=due // 60, minute=due % 60)
                    if (row and not row['ok'] and 0 <= (now - parsed(row['at'])).total_seconds() <= 600
                            and riskd.scanner_pending(bot, run, row['detail'], now.astimezone(ET))):
                        continue
                    good = bool(
                        row
                        and row["ok"] == 1
                        and parsed(row["at"]) >= due_at
                        and -30 <= (now - parsed(row["at"])).total_seconds()
                    )
                    if run == "session":
                        good = good and (now - parsed(row["at"])).total_seconds() <= 600
                    output.append(
                        Observation("heartbeat", bot, session, "digest", "healthy" if good else "failing", at, {"run": run})
                    )
            if minute >= 580:
                row = db.execute(
                    "SELECT action,at FROM decisions WHERE bot_id='sip_orb' AND at>=? AND at<? AND action IN ('UNIVERSE','SCANNER_UNAVAILABLE') ORDER BY id DESC LIMIT 1",
                    (lo, hi),
                ).fetchone()
                good = bool(
                    row
                    and row["action"] == "UNIVERSE"
                    and parsed(row["at"]).astimezone(ET).hour * 60 + parsed(row["at"]).astimezone(ET).minute < 580
                )
                output.append(Observation("sip_opening", "sip_orb", session, "page", "healthy" if good else "failing", at, {}))
            if minute >= close + 10:
                if db.execute("SELECT 1 FROM positions WHERE qty<>0 AND bot_id<>'spy_mr' LIMIT 1").fetchone():
                    output.append(Observation("position_after_close", "fleet", session, "page", "failing", at, {}))
    for name, url in [
        ("server_health", "http://127.0.0.1:8585/api/health"),
        ("platform_health", "https://www.mark2markets.com/api/healthcheck"),
    ]:
        try:
            payload = fetch_json(url, min(deadline, time.monotonic() + 8))
            evidence = {}
            good = payload.get("ok") is True
            if name == "server_health":
                stamp = payload.get("riskd_last", {}).get("at", "")
                good = good and 0 <= (now - parsed(stamp)).total_seconds() <= 90
                evidence["riskd_at"] = stamp
            output.append(Observation(name, "fleet", None, "page", "healthy" if good else "failing", at, evidence))
        except (OSError, ValueError, KeyError, TypeError):
            output.append(Observation(name, "fleet", None, "page", "failing", at, {"error": "READ_FAILED"}))
    try:
        readiness = fetch_json("http://127.0.0.1:8585/api/readiness", min(deadline, time.monotonic() + 8))
        account = readiness.get("paper_account")
        ready = isinstance(account, dict) and account.get("ready") is True
        output.append(Observation("valuation", "fleet", session, "page", "healthy" if ready else "failing", at, {}))
        output.append(Observation("local_read", "fleet", None, "page", "healthy", at, {}))
    except (OSError, ValueError, TypeError):
        output.append(Observation("local_read", "fleet", None, "page", "failing", at, {"error": "READ_FAILED"}))
    token = riskd.token_days_left()
    valid_token = token.get("present") is True and isinstance(token.get("days_left"), (int, float)) and token['days_left'] >= 2
    output.append(Observation("token", "fleet", None, "page", "healthy" if valid_token else "failing", at,
                              {"days_left": token.get("days_left")}))
    return output
