"""A separate operations database. Never accepts or opens the trading ledger."""

from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
from dataclasses import replace
from datetime import datetime, timedelta
from pathlib import Path

from .models import RECOVERABLE, ActionClaim, Observation, iso, parsed

SCHEMA = """
CREATE TABLE incidents(id INTEGER PRIMARY KEY, key TEXT UNIQUE, condition TEXT, scope TEXT,
 session_date TEXT, severity TEXT, state TEXT, first_at TEXT, last_at TEXT, acknowledged_at TEXT,
 last_good TEXT, good_tick TEXT, good_count INTEGER DEFAULT 0, attempts INTEGER DEFAULT 0,
 action_at TEXT, evidence_json TEXT, next_step TEXT);
CREATE TABLE incident_sources(incident_id INTEGER, ledger_id TEXT, alert_id INTEGER, acknowledged_at TEXT,
 PRIMARY KEY(incident_id,ledger_id,alert_id));
CREATE TABLE incident_events(id INTEGER PRIMARY KEY, incident_id INTEGER, at TEXT, kind TEXT, detail TEXT);
CREATE TABLE notification_outbox(id INTEGER PRIMARY KEY, incident_id INTEGER, event_id INTEGER UNIQUE,
 state TEXT DEFAULT 'pending', attempts INTEGER DEFAULT 0, next_at TEXT, error TEXT, claimed_at TEXT);
CREATE TABLE worker_state(key TEXT PRIMARY KEY, value_json TEXT);
"""
NEXT = {
    "position_mismatch": "Inspect the current position check: quantity, quote freshness and recorded stop. Two fresh healthy checks resolve recovered warnings.",
    "run_failed": "Review this bot's failed run and its decision log; commands are not automatically retried.",
    "server_health": "Check server task and fresh risk monitor evidence.",
    "token": "Renew shared authorization at https://www.mark2markets.com/trades/schwab-reauth",
    "sip_opening": "Review this session’s scanner publication and native selection; do not retry a late opening.",
    "order_rejected": "Review the recorded rejection; orders are not resubmitted.",
}


class IncidentStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        if self.path.is_symlink():
            raise ValueError("Unsafe operations path")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=1, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        version = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if version not in (0, 1):
            self.conn.close()
            raise ValueError("Unsupported incident schema")
        if version == 0:
            if self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchone():
                self.conn.close()
                raise ValueError("Unrecognized operations database")
            self.conn.executescript("BEGIN IMMEDIATE;" + SCHEMA + "PRAGMA user_version=1;COMMIT;")
        self.conn.execute("PRAGMA journal_mode=WAL")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.conn.close()

    @contextmanager
    def transaction(self):
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise

    def state(self, key, default=None):
        row = self.conn.execute("SELECT value_json FROM worker_state WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_state(self, key, value):
        self.conn.execute(
            "INSERT INTO worker_state VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",
            (key, json.dumps(value)),
        )

    def get(self, incident_id):
        return dict(self.conn.execute("SELECT * FROM incidents WHERE id=?", (incident_id,)).fetchone())

    def event(self, incident_id, at, kind, detail="", notify=False):
        cursor = self.conn.execute(
            "INSERT INTO incident_events(incident_id,at,kind,detail) VALUES(?,?,?,?)", (incident_id, at, kind, detail)
        )
        if notify:
            self.conn.execute(
                "INSERT INTO notification_outbox(incident_id,event_id,next_at) VALUES(?,?,?)", (incident_id, cursor.lastrowid, at)
            )
        return cursor.lastrowid

    def observe(self, observation: Observation, tick_id: str) -> int:
        with self.transaction():
            incident_id = self._observe(observation, tick_id)
            # Valuation describes the current shared account, not one session's
            # opening result. Keep dated history and apply both failures and
            # recovery samples to prior open cases, using the two-sample rule.
            if (observation.condition in {"valuation", "position_mismatch"} and observation.verdict in {"healthy", "failing", "unknown"}
                    and observation.session_date):
                previous = self.conn.execute(
                    "SELECT DISTINCT session_date FROM incidents WHERE condition=? "
                    "AND scope=? AND session_date<? AND state<>'resolved'",
                    (observation.condition, observation.scope, observation.session_date),
                ).fetchall()
                for row in previous:
                    self._observe(replace(observation, session_date=row[0], source_ids=()), tick_id)
            return incident_id

    def _observe(self, o, tick_id):
        if not re.fullmatch("[a-z_]{1,50}", o.condition) or o.verdict not in {"failing", "healthy", "unknown", "historical"}:
            raise ValueError("Invalid observation")
        parsed(o.at)
        if o.severity not in {"page", "digest", "info"} or len(o.scope) > 100:
            raise ValueError("Invalid observation identity")
        key = json.dumps([o.condition, o.scope, o.session_date])
        row = self.conn.execute("SELECT * FROM incidents WHERE key=?", (key,)).fetchone()
        if row is None and o.verdict == "healthy":
            return 0
        evidence = json.dumps(o.evidence, allow_nan=False)
        if len(evidence.encode()) > 65536:
            raise ValueError("Evidence too large")
        if row is None:
            state = "checking" if o.condition in RECOVERABLE and o.verdict == "failing" else "review"
            cur = self.conn.execute(
                """INSERT INTO incidents(key,condition,scope,session_date,severity,state,
                first_at,last_at,evidence_json,next_step) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    key,
                    o.condition,
                    o.scope,
                    o.session_date,
                    o.severity,
                    state,
                    o.at,
                    o.at,
                    evidence,
                    NEXT.get(o.condition, "Review the captured runtime evidence."),
                ),
            )
            incident_id = cur.lastrowid
            self.event(incident_id, o.at, "opened", notify=o.severity != "info")
            row = self.conn.execute("SELECT * FROM incidents WHERE id=?", (incident_id,)).fetchone()
        incident_id = row["id"]
        if o.verdict == "healthy" and parsed(o.at) < parsed(row["last_at"]):
            return incident_id
        state, count, good, good_tick = row["state"], row["good_count"], row["last_good"], row["good_tick"]
        if o.verdict == "healthy" and o.condition in RECOVERABLE:
            stamp = (o.evidence.get("riskd_at", o.at) if o.condition == "server_health" else
                     o.evidence.get("checked_at") if o.condition == "position_mismatch" else o.at)
            if not stamp or (o.condition == 'position_mismatch' and not 0 <= (parsed(o.at) - parsed(stamp)).total_seconds() <= 60):
                return incident_id
            valid = (parsed(row["first_at"]) < parsed(stamp) <= parsed(o.at)
                     and (not row["action_at"] or parsed(stamp) > parsed(row["action_at"])))
            if o.condition == 'position_mismatch' and not row['last_good']:
                valid = valid and parsed(stamp) > parsed(row['last_at'])
            if valid and tick_id != good_tick and (not good or parsed(stamp) > parsed(good)):
                count, good, good_tick = count + 1, stamp, tick_id
                if count >= 2:
                    state = "resolved"
        elif o.verdict != "healthy":
            count, good, good_tick = 0, None, None
            if state == "resolved":
                state = "checking" if o.condition in RECOVERABLE else "review"
            if o.verdict in {"unknown", "historical"}:
                state = "review"
        if state != row["state"]:
            self.event(incident_id, o.at, state, notify=o.severity != "info")
        elif o.severity == "page" and row["severity"] != "page":
            self.event(incident_id, o.at, "severity_increased", notify=True)
        self.conn.execute(
            """UPDATE incidents SET severity=?,state=?,last_at=?,last_good=?,good_tick=?,
            good_count=?,evidence_json=? WHERE id=?""",
            (o.severity, state, o.at, good, good_tick, count, evidence, incident_id),
        )
        for source in o.source_ids:
            self.conn.execute(
                "INSERT OR IGNORE INTO incident_sources(incident_id,ledger_id,alert_id) VALUES(?,?,?)",
                (incident_id, self.source_identity(), source),
            )
        return incident_id

    def source_identity(self):
        return str(self.state("ledger_identity", "unbound")) + ":" + str(self.state("generation", 0))

    def acknowledge_source(self, alert_id, at):
        self.conn.execute(
            "UPDATE incident_sources SET acknowledged_at=? WHERE alert_id=? AND ledger_id=?",
            (at, alert_id, self.source_identity()),
        )
        self.conn.execute(
            """UPDATE incidents SET acknowledged_at=? WHERE id IN
            (SELECT incident_id FROM incident_sources WHERE alert_id=? AND ledger_id=?)""",
            (at, alert_id, self.source_identity()),
        )

    def ingest_page(self, observations, cursor, ledger_identity, now):
        with self.transaction():
            self.set_state("ledger_identity", ledger_identity)
            for o in observations:
                self._observe(o, "ingest:" + iso(now))
            self.set_state("alert_cursor", cursor)
            self.set_state("ledger_identity", ledger_identity)

    def reserve_server_start(self, incident_id: int, now: datetime) -> ActionClaim | None:
        with self.transaction():
            previous = self.state("server_last_start")
            if previous and (now - parsed(previous)).total_seconds() < 1800:
                return None
            row = self.get(incident_id)
            if row["condition"] != "server_health" or row["state"] == "resolved":
                return None
            at = iso(now)
            self.set_state("server_last_start", at)
            claim_id = self.event(incident_id, at, "start_reserved")
            self.conn.execute(
                "UPDATE incidents SET state='recovering',action_at=?,attempts=attempts+1 WHERE id=?", (at, incident_id)
            )
            return ActionClaim(claim_id, incident_id, "start_owned_server", at, iso(now + timedelta(minutes=30)))

    def finish_action(self, claim_id, result, now):
        with self.transaction():
            row = self.conn.execute(
                "SELECT incident_id FROM incident_events WHERE id=? AND kind='start_reserved'", (claim_id,)
            ).fetchone()
            if not row:
                raise ValueError("Unknown claim")
            self.event(
                row[0], iso(now), "start_" + ("requested" if result == "started" else "failed"), notify=result != "started"
            )
            if result != "started":
                self.conn.execute("UPDATE incidents SET state='review' WHERE id=?", (row[0],))

    def complete_tick(self, tick_id, now, errors):
        with self.transaction():
            self.set_state("last_tick", {"id": tick_id, "at": iso(now), "errors": errors})
