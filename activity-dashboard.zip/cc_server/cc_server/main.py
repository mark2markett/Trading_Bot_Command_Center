"""Command Center server. Binds 127.0.0.1:8585. Serves /api and the built web app."""
# ruff: noqa: E402 -- repository SDK path must be set before application imports
from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

# Scheduled tasks launch from the repository root. Its outer cc_sdk directory
# otherwise shadows the editable package, leaving Bot/Order exports unavailable.
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "cc_sdk"))

from cc_sdk.control import control_dir
from cc_sdk.ledger import var_dir
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import api, position_monitor, riskd
from .alerts import Alerter, write_default_config
from .request_ledger import read_scope

DIST = ROOT / "cc_web" / "dist"


def setup_logging() -> None:
    logdir = var_dir() / "logs"
    logdir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format='{"t":"%(asctime)s","lvl":"%(levelname)s","src":"%(name)s","msg":%(message)r}',
                        handlers=[logging.FileHandler(logdir / "server.log"), logging.StreamHandler(sys.stdout)])


async def riskd_loop(stop: asyncio.Event) -> None:
    L = api.L()
    alerter = Alerter(L)
    while not stop.is_set():
        try:
            await asyncio.to_thread(riskd.tick, L, alerter)
        except Exception:  # noqa: BLE001
            logging.getLogger("riskd").exception("tick failed")
        try:
            await asyncio.wait_for(stop.wait(), timeout=15)
        except TimeoutError:
            pass


async def position_monitor_loop(stop: asyncio.Event) -> None:
    ledger = api.L()
    loop = asyncio.get_running_loop()
    while not stop.is_set():
        started = loop.time()
        try:
            await asyncio.to_thread(position_monitor.tick, ledger)
        except Exception:  # noqa: BLE001 -- failed observations must age out
            logging.getLogger('position_monitor').exception('position check failed')
        if stop.is_set():
            break
        delay = max(0, position_monitor.INTERVAL_SECONDS-(loop.time()-started))
        try:
            await asyncio.wait_for(stop.wait(), timeout=delay)
        except TimeoutError:
            pass


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    control_dir().mkdir(parents=True, exist_ok=True)
    write_default_config()
    stop = asyncio.Event()
    task = asyncio.create_task(riskd_loop(stop))
    positions = asyncio.create_task(position_monitor_loop(stop))
    yield
    stop.set()
    await task
    await positions


app = FastAPI(title="Trading Bot Command Center", version="0.1.0", lifespan=lifespan)
app.include_router(api.router)


@app.middleware('http')
async def isolate_api_reads(request, call_next):
    if request.method == 'GET' and request.url.path.startswith('/api/'):
        with read_scope():
            return await call_next(request)
    return await call_next(request)

def mount_dashboard(application: FastAPI, directory: Path) -> None:
    if not directory.exists():
        return
    application.mount("/assets", StaticFiles(directory=directory / "assets"), name="assets")

    @application.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path == 'api' or path.startswith('api/'):
            raise HTTPException(status_code=404, detail='Unknown API endpoint')
        f = directory / path
        if path and f.is_file():
            return FileResponse(f)
        return FileResponse(directory / "index.html")


mount_dashboard(app, DIST)

if __name__ == "__main__":
    import uvicorn
    reload = "--reload" in sys.argv
    uvicorn.run("cc_server.main:app", host="127.0.0.1", port=8585, reload=reload)
