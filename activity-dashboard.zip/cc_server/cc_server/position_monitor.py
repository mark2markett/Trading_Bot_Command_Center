"""Thirty-second ledger observations; never run a strategy or submit/settle orders.

Reuse riskd's account marks without provider requests. A ledger stop record
does not confirm broker protection. Writes are limited to metadata and alerts.
"""

from __future__ import annotations

import math
from copy import deepcopy
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from cc_sdk.options import contract_multiplier

from . import calendar, db
from .activity import TERMINAL, WORKING

INTERVAL_SECONDS = 30
MAX_AGE_SECONDS = 60
KEY = "position_monitor"


def saved_reports(L):
    try:
        value = db.kv_get(L, KEY, {})
    except (ValueError, TypeError):
        return {}
    return value if isinstance(value, dict) else {}


def valid_report(value):
    return (
        isinstance(value, dict)
        and isinstance(value.get("checked_at"), str)
        and value.get("status") in {"current", "review"}
        and value.get("interval_seconds") == INTERVAL_SECONDS
        and isinstance(value.get("position_identity"), list)
        and isinstance(value.get("issues"), list)
        and isinstance(value.get("positions"), list)
        and all(
            isinstance(p, dict)
            and {"symbol", "qty", "mark_price", "mark_at", "quote_status", "unrealized_usd", "stop_kind", "stop_price", "issues"}
            <= p.keys()
            for p in value["positions"]
        )
    )


def utcnow():
    return datetime.now(timezone.utc)


def market_open(at):
    local = at.astimezone(ZoneInfo("America/New_York"))
    close = tuple(map(int, calendar.close_time_str(local.date()).split(":")))
    return calendar.is_trading_day(local.date()) and (9, 30) <= (local.hour, local.minute) < close


def identity(positions):
    return [
        [p.get(k) for k in ("symbol", "qty", "avg_price", "stop_price", "updated_at")]
        for p in sorted(positions, key=lambda p: p["symbol"])
    ]


def positive(value):
    return isinstance(value, (float, int)) and math.isfinite(value) and value > 0


def age(value, at):
    try:
        parsed = datetime.fromisoformat(value)
        return (at - parsed).total_seconds() if parsed.tzinfo is not None else None
    except (TypeError, ValueError):
        return None


def observe_position(L, bot, p, at, trading):
    issues = []
    mark = L.one("SELECT price,at FROM paper_marks WHERE symbol=?", (p["symbol"],)) if bot["mode"] == "paper" else None
    mark_age = age(mark["at"], at) if mark else None
    valid = (
        mark is not None
        and positive(mark["price"])
        and mark_age is not None
        and 0 <= mark_age <= MAX_AGE_SECONDS
        and not L.one("SELECT 1 FROM kv WHERE key=?", (f"paper_mark_invalid:{p['symbol']}",))
    )
    quote_status = "market_closed" if not trading else "current" if valid else "unavailable"
    if trading and not valid:
        issues.append("quote_unavailable_or_stale")
    stop_kind, stop_price = "unverified", None
    if bot["mode"] == "paper" and bot["id"] == "spy_mr":
        stop_kind = "paper_daily_bar"
        observed = L.q("SELECT * FROM orders WHERE bot_id=? AND symbol=?", (bot["id"], p["symbol"]))
        # Include unknown statuses so an unclassified instruction cannot hide a conflict.
        active = [o for o in observed if str(o["status"]).lower() not in TERMINAL]
        stops = [o for o in active if o["type"] == "STOP"]
        exits = [o for o in active if o["type"] == "MOC"]
        side = "SELL" if p["qty"] > 0 else "BUY_TO_COVER"
        pending_exit = (
            len(active) == 1 and len(exits) == 1 and str(exits[0]["status"]).lower() in WORKING
            and exits[0]["qty"] == abs(p["qty"]) and exits[0]["side"] == side
            and str(exits[0]["broker_order_id"] or "").startswith("paper-")
            and not L.one("SELECT 1 FROM fills WHERE order_id=?", (exits[0]["id"],))
        )
        if pending_exit:
            # A queued simulator instruction is neither a fill nor stop protection.
            stop_kind = "paper_exit_pending"
        elif len(stops) == 1 and str(stops[0]["status"]).lower() in WORKING and stops[0]["qty"] == abs(p["qty"]) and stops[0]["side"] == side and positive(stops[0]["stop_price"]):
            stop_price = stops[0]["stop_price"]
            if p.get("stop_price") is not None and p["stop_price"] != stop_price:
                issues.append("stop_record_mismatch")
        else:
            issues.append("stop_record_missing_or_ambiguous")
    elif positive(p.get("stop_price")):
        stop_kind, stop_price = "strategy_managed", p["stop_price"]
    elif "options" not in bot["instrument"].lower():
        issues.append("stop_record_missing")
    if trading and valid and stop_price is not None:
        if (p["qty"] > 0 and mark["price"] <= stop_price) or (p["qty"] < 0 and mark["price"] >= stop_price):
            issues.append("stop_level_breached")
    pnl = (
        p["qty"] * (mark["price"] - p["avg_price"]) * contract_multiplier(p["symbol"])
        if trading and valid and positive(p["avg_price"])
        else None
    )
    return {
        "symbol": p["symbol"],
        "qty": p["qty"],
        "mark_price": mark["price"] if valid and trading else None,
        "mark_at": mark["at"] if mark else None,
        "quote_status": quote_status,
        "unrealized_usd": pnl,
        "stop_kind": stop_kind,
        "stop_price": stop_price,
        "issues": issues,
    }


def tick(L, at=None):
    at = at or utcnow()
    trading = market_open(at)
    reports = {}
    with L.transaction(write=False):
        for bot in db.bot_rows(L):
            positions = db.positions(L, bot["id"])
            observed = [observe_position(L, bot, p, at, trading) for p in positions]
            issues = sorted({issue for p in observed for issue in p["issues"]})
            reports[bot["id"]] = {
                "checked_at": at.isoformat(),
                "interval_seconds": INTERVAL_SECONDS,
                "status": "review" if issues else "current",
                "broker_verified": False,
                "position_identity": identity(positions),
                "positions": observed,
                "issues": issues,
            }
    with L.transaction():
        previous = saved_reports(L)
        for bot_id, report in reports.items():
            before = previous.get(bot_id)
            if report["issues"] and report["issues"] != (before.get("issues") if valid_report(before) else None):
                L.alert("digest", "position_mismatch", "Position monitor needs review: " + ", ".join(report["issues"]), bot_id)
        db.kv_set(L, KEY, reports)
    return reports


def inspect_report(report, positions, at):
    empty = {
        "status": "unavailable",
        "checked_at": None,
        "interval_seconds": INTERVAL_SECONDS,
        "broker_verified": False,
        "positions": [],
        "issues": [],
    }
    if not valid_report(report):
        return empty
    report = deepcopy(report)
    elapsed = age(report.get("checked_at"), at)
    if elapsed is None or elapsed < 0:
        return empty
    if elapsed > MAX_AGE_SECONDS:
        return {**report, "status": "overdue"}
    if identity(positions) != report.get("position_identity"):
        return {**empty, "status": "pending", "checked_at": report.get("checked_at")}
    # Readback only downgrades freshness; fetching a page never manufactures a check.
    for p in report["positions"]:
        elapsed = age(p.get("mark_at"), at)
        if p["quote_status"] == "current" and (elapsed is None or not 0 <= elapsed <= MAX_AGE_SECONDS):
            p.update(quote_status="unavailable", mark_price=None, unrealized_usd=None)
            report["status"] = "review"
            report["issues"] = sorted(set(report["issues"] + ["quote_unavailable_or_stale"]))
    return report


def readback(L, bot_id, at=None):
    with L.transaction(write=False):
        return inspect_report(saved_reports(L).get(bot_id), db.positions(L, bot_id), at or utcnow())
