"""Per-request read-only connections isolate dashboard reads from background writers."""
from contextlib import contextmanager
from contextvars import ContextVar

from cc_sdk.ledger import Ledger

_scope = ContextVar('api_read_ledger', default=None)


@contextmanager
def read_scope():
    state = {'ledger': None}
    token = _scope.set(state)
    try:
        yield
    finally:
        try:
            if state['ledger'] is not None:
                state['ledger'].conn.close()
        finally:
            _scope.reset(token)


def for_request(path=None):
    state = _scope.get()
    if state is None:
        return None
    if state['ledger'] is None:
        state['ledger'] = Ledger(path, readonly=True)
    return state['ledger']
