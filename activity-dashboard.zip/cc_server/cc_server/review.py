"""Read-only session review: observed facts, explicit links and honest evidence gaps."""
from __future__ import annotations

import json
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from . import calendar
from .activity import marked_position, number
from .review_events import candidates, text
from .review_findings import findings

ET = ZoneInfo('America/New_York')
MAX_ROWS = 10000
CATEGORIES = {'NO_SIGNAL':'no_signal', 'NO_BARS':'data_failure', 'NO_DATA':'data_failure',
              'NOQUOTE':'data_failure', 'SCANNER_UNAVAILABLE':'data_failure', 'ENTRY_PAUSED':'paused',
              'EXIT_BLOCKED':'exit_blocked', 'ENTER':'entered', 'EXIT':'exited', 'NONE':'passed'}


def total(values):
    values = list(values)
    return round(sum(values), 2) if all(number(v) for v in values) else None


def build_review(ledger, session_date, *, now=None):
    day = date.fromisoformat(session_date) if isinstance(session_date, str) else session_date
    if not isinstance(day, date) or not 2025 <= day.year <= 2027:
        raise ValueError('Calendar coverage is 2025–2027')
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError('Aware report timestamp required')
    start = datetime.combine(day, time(), ET)
    end = datetime.combine(day + timedelta(days=1), time(), ET)
    lo, hi = start.astimezone(timezone.utc).isoformat(), min(end, now + timedelta(microseconds=1)).astimezone(timezone.utc).isoformat()
    close = datetime.combine(day, time.fromisoformat(calendar.close_time_str(day)), ET)
    trading = calendar.is_trading_day(day)
    phase = 'future' if start > now else 'after_close' if now >= close + timedelta(minutes=30) else 'provisional'
    limits, gaps = [], []
    with ledger.transaction(write=False):
        def rows(table, timestamp='at'):
            # Existing native timestamps are UTC ISO strings; normalize comparison
            # through SQLite for legacy Z / offset representations as well.
            result = [dict(row) for row in ledger.q(
                f'SELECT * FROM {table} WHERE julianday({timestamp})>=julianday(?) AND julianday({timestamp})<julianday(?) ORDER BY id LIMIT ?',
                (lo, hi, MAX_ROWS + 1))]
            if len(result) > MAX_ROWS:
                limits.append(table)
            return result[:MAX_ROWS]
        bots = [dict(row) for row in ledger.q('SELECT id,name,mode,version,instrument FROM bots ORDER BY name')]
        orders, fills, trades, decisions = rows('orders'), rows('fills'), rows('trades', 'exit_at'), rows('decisions')
        heartbeats = rows('heartbeats')
        positions = [dict(row) for row in ledger.q('SELECT * FROM positions WHERE qty<>0')] if day == now.astimezone(ET).date() else []
        marks = {row['symbol']:dict(row) for row in ledger.q('SELECT * FROM paper_marks')}
        invalid = {row['key'].split(':',1)[1] for row in ledger.q("SELECT key FROM kv WHERE key LIKE 'paper_mark_invalid:%'")}
        positions = [marked_position(row, marks.get(row['symbol']), invalid, now) for row in positions]
    for row in orders:
        row['reason'] = text(row['reason'])
        row.pop('risk_result_json', None)
    for row in heartbeats:
        row.pop('detail', None)  # raw errors/tracebacks may contain private provider data
    decision_records = []
    for row in decisions:
        if row['action'] == 'TRADE_EVIDENCE':
            continue
        try:
            signal = json.loads(row['signal_json'])
        except (ValueError, TypeError):
            signal = {}
        decision_records.append({'id':row['id'], 'bot_id':row['bot_id'], 'at':row['at'],
                                 'action':row['action'], 'category':CATEGORIES.get(row['action'], 'other'),
                                 'symbol':text(signal.get('symbol')) if isinstance(signal, dict) else '', 'reason':text(row['reason'])})
    linked = candidates(decisions, orders, fills, trades)
    linked_trades = {tid for candidate in linked for tid in candidate['trade_ids']}
    legacy = sum(row['id'] not in linked_trades for row in trades)
    modes = {bot['id']: bot['mode'] for bot in bots}
    simulated = sum(modes.get(row['bot_id']) == 'paper' or str(row.get('broker_order_id') or '').lower().startswith('paper') for row in orders)
    refs = sum(modes.get(row['bot_id']) != 'paper' and row.get('broker_order_id') is not None and not str(row['broker_order_id']).lower().startswith('paper') for row in orders)
    if legacy:
        gaps.append('Historical trades lack explicit candidate/order/exit links; attribution is unverified.')
    gaps.extend(['Only recorded candidates are covered; complete scanner-universe capture is not established.',
                 'Missed-trade option P&L is unmeasurable without point-in-time contracts, executable quotes and a fixed comparison rule.',
                 'Market regime, earnings calendar, Greeks not supplied by the provider, and unsampled option paths remain unknown.'])
    if day != now.astimezone(ET).date():
        gaps.append('Historical close holdings and open P&L cannot be reconstructed from the current position table.')
    if limits:
        gaps.append('Source row limit reached: ' + ', '.join(limits) + '; metrics are partial.')
    per_bot = []
    for bot in bots:
        closed = [row for row in trades if row['bot_id'] == bot['id']]
        per_bot.append({**bot, 'closed_trades':len(closed), 'recorded_closed_pnl':total(row['pnl'] for row in closed),
                        'orders':sum(row['bot_id'] == bot['id'] for row in orders),
                        'fills':sum(row['bot_id'] == bot['id'] for row in fills),
                        'candidates':sum(row['bot_id'] == bot['id'] for row in linked),
                        'decisions':dict(Counter(row['category'] for row in decision_records if row['bot_id'] == bot['id']))})
    valid_pnls = [row['pnl'] for row in trades if number(row['pnl'])]
    report = {
        'schema_version':1, 'session_date':day.isoformat(), 'generated_at':now.isoformat(), 'phase':phase,
        'session':{'trading_day':trading, 'close_at':close.isoformat(), 'report_due_at':(close + timedelta(minutes=30)).isoformat(),
                   'friday':day.weekday() == 4, 'third_friday':day.weekday() == 4 and 15 <= day.day <= 21,
                   'expiration_activity':'Context only; contract expirations and observed liquidity determine exposure.'},
        'execution':{'broker_verified':False, 'local_simulated_orders':simulated, 'broker_reference_only':refs,
                     'basis':'Local paper simulation; no Schwab-side paper execution or broker reconciliation is certified.'},
        'summary':{'closed_trades':len(trades), 'recorded_closed_pnl':total(row['pnl'] for row in trades),
                   'recorded_fill_fees':total(row['commission'] for row in fills), 'net_closed_pnl':None,
                   'win_rate':sum(pnl > 0 for pnl in valid_pnls)/len(trades) if trades and len(valid_pnls) == len(trades) else None,
                   'orders':len(orders), 'fills':len(fills), 'rejected_orders':sum(str(row['status']).lower() == 'rejected' for row in orders),
                   'observed_candidates':len(linked)},
        'pnl_basis':'Closed P&L is the recorded trade result. Fill fees are a separate session total and may include entries still open; net closed P&L needs complete explicit fill linkage.',
        'positions':{'items':positions, 'observed_at':now.isoformat(), 'as_of_session_close':False,
                     'open_pnl':total(row['open_pnl'] for row in positions) if day == now.astimezone(ET).date() else None,
                     'basis':'Current stored holdings at report generation; not an exchange-close position snapshot.'},
        'bots':per_bot, 'decisions':dict(Counter(row['category'] for row in decision_records)),
        'decision_records':decision_records[-500:], 'orders':orders[-500:], 'fills':fills[-500:], 'trades':trades[-500:],
        'heartbeats':heartbeats[-100:], 'candidates':linked[-100:],
        'counterfactual':{'pnl':None, 'status':'Unmeasurable: missing complete historical option books and predeclared comparison rules.'},
        'coverage':{'legacy_trades':legacy, 'partial':bool(limits), 'gaps':gaps,
                    'display_limits':'500 decisions/orders/fills/trades, 100 candidates/heartbeats; totals cover up to 10,000 source rows per table.'},
    }
    report['findings'] = findings({**report, 'heartbeats':heartbeats, 'decision_records':decision_records, 'orders':orders})
    return report
