"""Explicit evidence links only; temporal proximity never proves a trade relationship."""
import json
import re
from datetime import datetime

from cc_sdk.options import parse_occ
from cc_sdk.trade_evidence import PHASES, clean

from .activity import number


def text(value):
    value = re.sub(r'https?://\S+', '[URL]', str(value or '').split('Traceback')[0])
    return value[:300]


def verified_spread_lifecycle(group, order_map, fills, trade_map):
    """Certify only a complete, unambiguous two-leg debit vertical round trip."""
    entries = [e for e in group['events'] if e['phase'] == 'entry']
    exits = [e for e in group['events'] if e['phase'] == 'exit']
    if len(entries) != 1 or len(exits) != 1:
        return False
    entry, exit_event = entries[0], exits[0]
    entry_ids, exit_ids = entry['details'].get('order_ids'), exit_event['details'].get('order_ids')
    if (not isinstance(entry_ids, list) or not isinstance(exit_ids, list)
            or len(entry_ids) != 2 or len(exit_ids) != 2
            or any(type(oid) is not int or oid not in order_map for oid in entry_ids + exit_ids)
            or len(set(entry_ids + exit_ids)) != 4
            or exit_event['details'].get('pnl_basis') != 'gross_before_recorded_commissions'):
        return False
    opened, closed = [order_map[oid] for oid in entry_ids], [order_map[oid] for oid in exit_ids]
    if ({row['side'] for row in opened} != {'BUY_TO_OPEN', 'SELL_TO_OPEN'}
            or {row['side'] for row in closed} != {'SELL_TO_CLOSE', 'BUY_TO_CLOSE'}):
        return False
    long = next(row for row in opened if row['side'] == 'BUY_TO_OPEN')
    short = next(row for row in opened if row['side'] == 'SELL_TO_OPEN')
    try:
        long_contract, short_contract = parse_occ(long['symbol']), parse_occ(short['symbol'])
        if long_contract[:3] != short_contract[:3] or long_contract[3] == short_contract[3]:
            return False
        if (long_contract[2] == 'C' and long_contract[3] > short_contract[3]) or (long_contract[2] == 'P' and long_contract[3] < short_contract[3]):
            return False
        if datetime.fromisoformat(entry['at'].replace('Z','+00:00')) > datetime.fromisoformat(exit_event['at'].replace('Z','+00:00')):
            return False
    except (ValueError, TypeError, KeyError):
        return False
    qty = long['qty']
    if not number(qty) or qty <= 0 or any(row['qty'] != qty or row['bot_id'] != group['bot_id'] for row in opened + closed):
        return False
    if {(row['side'],row['symbol']) for row in closed} != {('SELL_TO_CLOSE',long['symbol']),('BUY_TO_CLOSE',short['symbol'])}:
        return False
    cashflow = 0.0
    for row in opened + closed:
        linked = [f for f in fills if f['order_id'] == row['id']]
        if (not linked or any(f['bot_id'] != group['bot_id'] or not number(f['qty']) or f['qty'] <= 0
                             or not number(f['price']) or f['price'] < 0 for f in linked)
                or sum(f['qty'] for f in linked) != qty):
            return False
        cashflow += sum(f['qty'] * f['price'] * 100 for f in linked) * (1 if row['side'].startswith('SELL') else -1)
    tid = exit_event['details'].get('trade_id')
    trade = trade_map.get(tid) if type(tid) is int else None
    return bool(trade and trade['bot_id'] == group['bot_id'] and trade['qty'] == qty
                and number(trade['pnl']) and abs(round(cashflow,2) - trade['pnl']) <= .01)


def candidates(decisions, orders, fills, trades):
    groups = {}
    for row in decisions:
        if row['action'] != 'TRADE_EVIDENCE':
            continue
        try:
            data = json.loads(row['signal_json'])
            if (not isinstance(data, dict) or data.get('schema_version') != 1
                    or not re.fullmatch('[a-f0-9]{32}', str(data.get('candidate_id', '')))
                    or data.get('phase') not in PHASES):
                continue
            key = data['candidate_id']
            group = groups.setdefault(key, {'id': key, 'bot_id': row['bot_id'], 'symbol': text(data.get('symbol')),
                                           'rule_version': text(data.get('rule_version')), 'events': []})
            if group['bot_id'] != row['bot_id']:
                continue
            group['events'].append({'decision_id': row['id'], 'at': row['at'], 'phase': data['phase'],
                                    'details': clean(data.get('details', {}))})
        except (ValueError, TypeError, KeyError):
            continue
    order_map = {row['id']: row for row in orders}
    trade_map = {row['id']: row for row in trades}
    claims = {}
    for group in groups.values():
        for event in group['events']:
            details = event['details']
            if not isinstance(details, dict):
                continue
            refs = details.get('order_ids', [])
            for oid in refs if isinstance(refs, list) else []:
                if type(oid) is int:
                    claims.setdefault(('order',oid),set()).add(group['id'])
            tid = details.get('trade_id')
            if type(tid) is int:
                claims.setdefault(('trade',tid),set()).add(group['id'])
    output = []
    for group in groups.values():
        gaps, order_ids, trade_ids, samples = [], set(), set(), []
        for event in group['events']:
            details = event['details']
            if not isinstance(details, dict):
                continue
            for oid in details.get('order_ids', []) if isinstance(details.get('order_ids'), list) else []:
                if type(oid) is int and oid in order_map and order_map[oid]['bot_id'] == group['bot_id']:
                    order_ids.add(oid)
                else:
                    gaps.append('An explicit order link is absent from this session or belongs to another bot.')
            tid = details.get('trade_id')
            if type(tid) is int and tid in trade_map and trade_map[tid]['bot_id'] == group['bot_id']:
                trade_ids.add(tid)
            if event['phase'] != 'observation' or details.get('quote_status') != 'current':
                continue
            try:
                at = datetime.fromisoformat(event['at'].replace('Z', '+00:00'))
                books = details.get('books')
                valid = (at.tzinfo is not None and isinstance(books, list) and len(books) == 2
                         and all(isinstance(q, dict) and number(q.get('quote_time'))
                                 and 0 <= at.timestamp() - q['quote_time'] <= 60
                                 and number(q.get('bid')) and number(q.get('ask')) and 0 < q['bid'] <= q['ask'] for q in books))
                value, cost = details.get('liquidation_value_usd'), details.get('entry_cost_usd')
                if valid and number(value) and number(cost):
                    samples.append({'at':event['at'], 'pnl':round(value - cost, 2), 'oldest_quote_age_seconds':round(max(at.timestamp()-q['quote_time'] for q in books),3)})
            except (ValueError, TypeError, OverflowError):
                continue
        phases = {event['phase'] for event in group['events']}
        outcome = ('closed' if trade_ids else 'entered' if 'entry' in phases else
                   'risk_rejected' if 'risk_rejected' in phases else 'passed' if 'passed' in phases else 'incomplete')
        if 'candidate' not in phases:
            gaps.append('Original candidate evidence is outside this session or unavailable.')
        if 'entry' in phases and not order_ids:
            gaps.append('No verified session order links.')
        if 'exit' in phases and not trade_ids:
            gaps.append('Exit evidence has no matching closed-trade row in this session.')
        owned_fills = [row for row in fills if row['order_id'] in order_ids and row['bot_id'] == group['bot_id']]
        if 'exit' in phases:
            for oid in order_ids:
                quantities = [row['qty'] for row in owned_fills if row['order_id'] == oid]
                if not quantities or not all(number(qty) for qty in quantities) or sum(abs(qty) for qty in quantities) != abs(order_map[oid]['qty']):
                    gaps.append('Linked fill coverage is incomplete; net closed P&L is unverified.')
            if not all(event['details'].get('order_ids') for event in group['events'] if event['phase'] in ('entry','exit') and isinstance(event['details'],dict)):
                gaps.append('Entry or exit fill links are missing; net closed P&L is unverified.')
        if any(len(claims.get((kind,row_id),set())) > 1 for kind,ids in [('order',order_ids),('trade',trade_ids)] for row_id in ids):
            gaps.append('Lifecycle source links are claimed by multiple candidates; attribution and net P&L are unverified.')
        if 'exit' in phases and (len(trade_ids) != 1 or len(order_ids) != 4 or not verified_spread_lifecycle(group, order_map, fills, trade_map)):
            gaps.append('Complete distinct entry/exit option lifecycle and gross P&L basis are unverified; net closed P&L is unavailable.')
        pnl = [trade_map[tid]['pnl'] for tid in trade_ids]
        fee_values = [row['commission'] for row in owned_fills]
        gross = round(sum(pnl), 2) if pnl and all(number(v) for v in pnl) else None
        fees = round(sum(fee_values), 2) if owned_fills and all(number(v) for v in fee_values) else None
        # A closed candidate needs entry AND exit evidence to establish full fill coverage.
        net = round(gross - fees, 2) if gross is not None and fees is not None and {'entry','exit'} <= phases and not gaps else None
        output.append({**group, 'outcome': outcome, 'order_ids': sorted(order_ids), 'trade_ids': sorted(trade_ids),
                       'orders': [order_map[oid] for oid in sorted(order_ids)], 'fills': owned_fills,
                       'recorded_pnl': gross, 'recorded_fees': fees, 'net_pnl': net, 'gaps': sorted(set(gaps)),
                       'observed_path': {'sample_count': len(samples), 'best_pnl': max(sample['pnl'] for sample in samples) if samples else None,
                                         'worst_pnl': min(sample['pnl'] for sample in samples) if samples else None,
                                         'first_at':samples[0]['at'] if samples else None, 'last_at':samples[-1]['at'] if samples else None,
                                         'oldest_quote_age_seconds':max(sample['oldest_quote_age_seconds'] for sample in samples) if samples else None,
                                         'basis': 'Sampled long-bid minus short-ask liquidation value less entry debit; excludes fees. Not a complete MAE/MFE path.'}})
    return output
