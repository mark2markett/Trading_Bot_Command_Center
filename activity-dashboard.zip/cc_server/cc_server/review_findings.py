"""Evidence-citing review findings; no order, control or parameter writes."""


def findings(report):
    output = []
    def add(category, title, action, refs):
        output.append({'category': category, 'title': title, 'action': action, 'evidence': refs})
    add('execution_capability', 'Schwab-side paper execution is not established',
        'Establish a supported paper API/account and reconcile broker orders, fills and holdings before certifying broker execution.',
        [f"{report['execution']['local_simulated_orders']} local simulated orders; {report['execution']['broker_reference_only']} unverified broker references"])
    failed = [row for row in report['heartbeats'] if row['ok'] == 0]
    if failed:
        add('operational_failure', 'Run failures were recorded',
            'Inspect the failed run and its decision log, then verify a subsequent healthy run. A later success does not erase a recorded failure.',
            ['heartbeat:' + str(row['id']) + ' ' + row['bot_id'] + ' ' + row['run'] for row in failed[:10]])
    data = [item for item in report['decision_records'] if item['category'] == 'data_failure']
    if data:
        add('data_quality', 'Data failures were recorded',
            'Repair the recorded data dependency before evaluating whether entry filters should change.',
            ['decision:' + str(item['id']) for item in data[:10]])
    rejected = [row for row in report['orders'] if str(row['status']).lower() == 'rejected']
    if rejected:
        add('risk_execution', 'Orders were rejected', 'Review each recorded risk or execution rejection; do not relax limits or resubmit automatically.',
            ['order:' + str(row['id']) + ' ' + row['reason'] for row in rejected[:10]])
    gates = [(candidate,event) for candidate in report['candidates'] for event in candidate['events'] if event['phase'] == 'risk_rejected']
    if gates:
        add('risk_gate', 'Candidate entries were refused by risk checks',
            'Review sizing, available portfolio capacity and each recorded risk reason. Keep limits unchanged while comparing alternatives.',
            ['decision:' + str(event['decision_id']) + ' ' + candidate['symbol'] for candidate,event in gates[:10]])
    blocked = [item for item in report['decision_records'] if item['category'] == 'exit_blocked']
    if blocked:
        add('exit_management', 'An exit was blocked', 'Inspect the current position and the recorded refusal. Preserve risk controls and reconcile before retrying.',
            ['decision:' + str(item['id']) for item in blocked[:10]])
    if report['summary']['closed_trades'] < 20:
        add('research', 'Insufficient closed-trade evidence for strategy changes',
            'Accumulate forward paper observations and compare a versioned hypothesis with the unchanged baseline. Twenty observations alone do not establish an edge.',
            [f"{report['summary']['closed_trades']} closed trades in this session"])
    if report['coverage']['legacy_trades']:
        add('coverage', 'Older trades lack explicit lifecycle links', 'Retain recorded results; collect new evidence before attributing selection, execution or exit effects.',
            [f"{report['coverage']['legacy_trades']} closed trades without explicit candidate links"])
    return output
