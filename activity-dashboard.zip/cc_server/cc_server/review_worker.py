"""Calendar-aware report generation, isolated from execution and risk writes."""
from __future__ import annotations

import json
import os
import re
import sqlite3
import tempfile
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

from cc_sdk.ledger import Ledger

from . import calendar
from .review import ET, build_review


def due_session(now):
    today = now.astimezone(ET).date()
    if not 2025 <= today.year <= 2027:
        raise ValueError('Calendar coverage is 2025–2027')
    day = today
    for _ in range(14):
        if day.year < 2025:
            return None
        due = datetime.combine(day, time.fromisoformat(calendar.close_time_str(day)), ET) + timedelta(minutes=30)
        if calendar.is_trading_day(day) and now >= due:
            return day
        day -= timedelta(days=1)
    return None


def safe_output(runtime, filename):
    folder = Path(runtime) / 'reviews'
    path = folder / filename
    if folder.is_symlink() or path.is_symlink() or getattr(folder, 'is_junction', lambda: False)():
        raise ValueError('Unsafe review output path')
    if not re.fullmatch(r'(?:\d{4}-\d{2}-\d{2}\.(?:json|md)|latest\.json)', filename):
        raise ValueError('Unexpected review filename')
    return path


def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.review-', delete=False) as stream:
        stream.write(value)
        temporary = Path(stream.name)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_saved(runtime, day):
    path = safe_output(runtime, day.isoformat() + '.json')
    if not path.exists():
        return None
    if path.stat().st_size > 20_000_000:
        raise ValueError('Saved review exceeds size limit')
    result = json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(result, dict) or result.get('schema_version') != 1 or result.get('session_date') != day.isoformat()
            or result.get('ledger') != str((Path(runtime) / 'cc.db').resolve(strict=True))):
        raise ValueError('Saved review identity differs')
    return result


def stored_reports(runtime):
    folder = Path(runtime) / 'reviews'
    output = {'reports': [], 'worker': {'status': 'unavailable', 'interval_seconds': 60}}
    if not folder.exists() or folder.is_symlink():
        return output
    try:
        status_path = safe_output(runtime, 'latest.json')
        if status_path.exists():
            status = json.loads(status_path.read_text(encoding='utf-8'))
            stamp = datetime.fromisoformat(status['checked_at'])
            age = (datetime.now(timezone.utc) - stamp).total_seconds()
            output['worker'] = {**status, 'status': 'overdue' if not 0 <= age <= 180 else status['status'], 'interval_seconds':60}
        for path in sorted(folder.glob('????-??-??.json'), reverse=True)[:30]:
            day = date.fromisoformat(path.stem)
            saved = read_saved(runtime, day)
            if saved:
                output['reports'].append({key:saved[key] for key in ('session_date','generated_at','saved_at','phase','summary')})
    except (OSError, ValueError, KeyError, TypeError):
        output['worker'] = {'status':'error','error':'SAVED_REVIEW_UNAVAILABLE','interval_seconds':60}
    return output


def markdown(report):
    def line(value):
        return str(value).replace('\n',' ').replace('`', "'").replace('|','/').replace('<','&lt;').replace('>','&gt;')
    summary = report['summary']
    lines = [f"# Command Center review — {report['session_date']}", '',
             f"Generated: {report['generated_at']}. Phase: {report['phase']}.", '',
             report['execution']['basis'], '',
             f"Closed trades: {summary['closed_trades']}; recorded closed P&L: {summary['recorded_closed_pnl']}; session fill fees: {summary['recorded_fill_fees']}.", '',
             report['pnl_basis'], '', '## Findings', '']
    for finding in report['findings']:
        lines.extend([f"- **{line(finding['title'])}**: {line(finding['action'])}",
                      '  Evidence: ' + '; '.join(line(item) for item in finding['evidence'])])
    lines.extend(['', '## Recorded run outcomes', ''])
    for item in report['heartbeats']:
        lines.append(f"- heartbeat:{item['id']} {line(item['at'])} {line(item['bot_id'])} {line(item['run'])}: {'OK' if item['ok'] else 'Failed'}")
    lines.extend(['', '## Decisions and passed opportunities', ''])
    for item in report['decision_records']:
        lines.append(f"- decision:{item['id']} {line(item['at'])} {line(item['bot_id'])} {line(item['symbol'])} {line(item['category'])}: {line(item['reason'])}")
    lines.extend(['', '## Evidence gaps', ''])
    lines.extend('- ' + line(gap) for gap in report['coverage']['gaps'])
    return '\n'.join(lines) + '\n'


def tick(runtime, *, now=None):
    runtime = Path(runtime).resolve(strict=True)
    now = now or datetime.now(timezone.utc)
    status = {'status':'error', 'checked_at':now.isoformat(), 'interval_seconds':60}
    try:
        day = due_session(now)
        if day is None:
            status.update(status='waiting', session_date=None)
        elif read_saved(runtime, day) is not None:
            status.update(status='already_saved', session_date=day.isoformat())
        else:
            ledger = Ledger(runtime / 'cc.db', readonly=True)
            try:
                report = build_review(ledger, day, now=now)
            finally:
                ledger.conn.close()
            report.update(saved_at=now.isoformat(), stored=True, ledger=str((runtime / 'cc.db').resolve(strict=True)))
            # JSON is the completion marker. A crash before its atomic publication
            # leaves the session pending and safely regenerable on the next tick.
            atomic(safe_output(runtime, day.isoformat()+'.md'), markdown(report).encode())
            atomic(safe_output(runtime, day.isoformat()+'.json'), (json.dumps(report, allow_nan=False, indent=2)+'\n').encode())
            status.update(status='written', session_date=day.isoformat())
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error) as error:
        status['error'] = type(error).__name__
    try:
        atomic(safe_output(runtime, 'latest.json'), (json.dumps(status)+'\n').encode())
    except (OSError, ValueError):
        pass
    return status
