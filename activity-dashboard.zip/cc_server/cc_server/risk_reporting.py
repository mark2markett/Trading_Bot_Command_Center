"""Read-only presentation boundary: unknown account values are never zero risk."""

from math import isfinite

from cc_sdk.ledger import Ledger

from . import db, parity, riskd


def parity_snapshot(ledger: Ledger) -> dict:
    """Evaluate display metrics; riskd owns cache updates and alert delivery."""
    return {bot["id"]: parity.evaluate(bot.get("backtest") or {}, db.trades(ledger, bot["id"]),
                                      db.fills(ledger, bot["id"], 200)) for bot in db.bot_rows(ledger)}


def portfolio_metrics(ledger: Ledger) -> tuple[dict, dict]:
    drawdown = riskd.portfolio_drawdown(ledger)
    exposure = riskd.gross_exposure(ledger)
    equity = drawdown.get("equity")
    if equity is None or not isfinite(equity) or equity <= 0:
        drawdown = {**drawdown, "dd": None, "equity": None, "peak": None}
        exposure = {**exposure, "usd": None, "ratio": None}
    return drawdown, exposure
