# Closed-loop handoff to Mark

Delivered `test/closed-loop` head: `b220dbda4f3bc58d003d5bc110f519e57cd02e5c`.
Base: `2783f2eae2657a9d60b37f4ac5053715633ed683` (`feat/options-m7`).

## Monday server recovery: b220dbd

The Windows server remained listening but all five API probes timed out. Riskd logged SQLite API misuse and a json.loads(None) error. A child-process regression reproduced the exact SQLite API misuse during simultaneous real dashboard API requests and riskd.tick against valid disposable data. Additional fixtures reproduced wrong/missing parameterized rows, JSON read failures and concurrent legacy position-migration failures.

Ledger now uses a per-instance reentrant lock around execute, complete result fetching/lastrowid and cursor closure. Existing migration runs under the same lock. Riskd now logs exception tracebacks. No trading rules, risk limits, authentication flow or stored data are reset/defaulted. The fix changes four files only (Ledger, server logging and two test files), and can be cherry-picked independently onto feat/options-m7. It does not require merging the complete harness branch or main.

Verification: 161 Python tests passed, one existing FastAPI/TestClient warning; four targeted regressions passed after the minor review cleanup. Changed-file Ruff and whitespace passed. Independent review found no Critical or Important production findings. The reviewer noted Windows venv redirector timeout ownership in the new test helper; the helper now launches the actual interpreter with the established CPython venv protocol, with no harness-module dependency.

Full browser harness: 34 PASS / 0 FAIL / 7 NOT COVERED, exit 0. Owned runtime/imports were removed. Updated bundle fetch/cherry-pick was verified against an originless original-base checkout, preserving feat/options-m7, unrelated tracked/untracked files and disposable runtime sentinel bytes. Application to the user's current Windows repo and server restart are still pending.

Mark's preceding Windows UI-fix run at d89ceab passed 39 checks with zero failures and two gaps, matching live fingerprints and restoring feat/options-m7. Remaining real Schwab and scheduled/live/scanner integrations require operational follow-up; the Monday server failure is being resolved first.

Before restarting, preserve the server log and a consistent SQLite snapshot. Verify a port-8585 listener's process command identifies cc_server.main before stopping that process. Stop only the CC server scheduled task if active; leave bot tasks/windows alone. Retrieve the bundle, fetch test/closed-loop, stay on feat/options-m7 and cherry-pick b220dbda4f3bc58d003d5bc110f519e57cd02e5c. Start .venv\Scripts\python.exe -u -m cc_server.main, then recheck health/bots/risk/alerts/research with bounded read-only requests. Do not merge main, remove databases, or silently replace malformed JSON. A separate persistent NULL/malformed record requires inspecting metadata and handling it explicitly; this cloud reproduction does not establish the content of the Windows database.

## Windows startup correction

The original Windows run passed 17 checks, including real Polygon data, both historical replays, actual synthetic strategies, and before/after live fingerprints. Dashboard startup stopped before controls. Mark's subprocess probe returned launch_pid=10140 and python_pid=15124: the Windows venv redirector starts a separate interpreter.

Commit `33281cd` launches the actual base interpreter using CPython's venv-launcher protocol for both harness worker and server. It retains the selected virtual environment and mandatory exact PID/nonce/runtime checks. Startup failures now report fixed diagnostic codes and preserve `server-startup.json` (numeric PID/match fields, no raw identity responses) plus `server-process.log` beside reports after runtime cleanup. Mark verified this launcher correction with both browser-free and browser-enabled Windows runs. The latter reached 38 PASS / 1 FAIL / 2 NOT COVERED, with matching live fingerprints, cleanup, and restoration of feat/options-m7. The only failure was the spread button fixed below.

## Spread-button correction (d89ceab)

Mark explicitly asked to address the errors after the browser-enabled Windows run. The real page previously enabled Flatten only when exactly one position was open; a two-leg spread had a null single-position display value and the button was disabled.

Flatten now uses the existing nonzero-position list: enabled for one or multiple open positions; disabled for no positions or zero-quantity holdings. The confirmation text correctly says all open positions. Confirmation action, exact-word gating, API routing and bot behavior are unchanged. Only BotPage.tsx and its component tests changed in this commit; no backend, strategy or SDK trading behavior changed.

## Verified results

Five new component regressions cover empty/zero holdings, single long/short positions, and a two-leg spread with real confirmation dialog and exact-word gating/cancel. The spread test failed on the old condition before the correction, then passed. Full web suite: **10 passed**. TypeScript/Vite build, changed-file oxlint and whitespace checks passed. Focused independent review found no Critical or Important issues. Python files were unchanged; the previously verified Python suite had 157 passes and one existing dependency warning.

Complete cloud browser run after correction: **34 PASS / 0 FAIL / 7 NOT COVERED**, exit 0. The actual spread Flatten button passes and the confirmed API closes the paper spread and persists its trade. [Complete report](report.md), [JSON](report.json), [verification metadata](verification.json), [fleet screenshot](screenshots/fleet.png), [spread screenshot](screenshots/gap_go_spread.png), and [startup identity](server-startup.json) are included. Mark has now verified this UI correction on Windows: 39 PASS / 0 FAIL / 2 NOT COVERED, exit 0.

Actual five manifests/rules, SDK risk, paper fills, ledger, FastAPI app, rendered dashboard and controls ran with explicitly SYNTHETIC prices/chains/calendars. Oversized orders/premium, stale chains, pause/exit/resume, flatten, kill/re-arm and 16 audit-before-flag observations passed. Reachability: **197/314 source functions observed; 117 unobserved**. Observation does not establish every behavior is tested.

238 supported Python filesystem/SQLite write operations were observed with no outside attempts. This is not an OS-wide native-library trace. Owned server and bot handles closed, runtime/imports were removed, and diagnostic/log/report/screenshots retained. Cloud source var stayed absent; port 8586 had no listener afterward.

Seven cloud gaps remain: before/after Windows live fingerprints, real Schwab, real Polygon, two historical replays, and scheduled/live/scanner integrations. Mark's browser-enabled Windows run before this UI correction covered fingerprints, Polygon and both replays. Its two gaps were Schwab and scheduled/live/scanner integrations. Logical live fingerprints exclude heartbeats/kv; the cloud source-only bundle cannot independently verify Windows live state.

Broker/shared-state Schwab authentication is excluded because it can refresh remote state. Polygon uses an already injected key only; credential files are never opened. No real orders/alerts, production port 8585, schedules, Supabase/Vercel writes or main merges were performed. Mark separately authorized publishing artifacts on GitHub transfer/closed-loop-bundle after direct downloads were unavailable.

## Retrieve and import

Use a fresh temporary clone of the authorized transfer branch:

```powershell
$transfer = Join-Path $env:TEMP ('cc-transfer-' + [guid]::NewGuid().ToString('N'))
git clone --depth 1 --single-branch --branch transfer/closed-loop-bundle https://github.com/mark2markett/Trading_Bot_Command_Center.git $transfer
Set-Location C:\Users\Administrator\trading_bots\command-center
$bundle = Join-Path $transfer 'command-center-closed-loop.bundle'
git bundle verify $bundle
git -c gc.auto=0 fetch $bundle 'test/closed-loop:test/closed-loop'
```

Fetching adds/updates the test branch and preserves the currently checked-out branch and working files. Updated bundle import was verified against an originless original-base clone with intentional tracked/untracked changes and disposable live-record sentinel: branch/status/files stayed identical. Never force a divergent fetch. The incremental bundle requires base 2783f2e. `closed-loop.patch` is a fallback, not an extra patch after importing the bundle.

## Run locally

Temporarily switch to `test/closed-loop`, run `npm run build` in `cc_web` so the sandbox serves the corrected UI, then run `.venv\Scripts\python.exe scripts\closed_loop.py`, and restore `feat/options-m7` in a PowerShell finally block. Preserve intentional bot.log/dev.sh/handoff changes; no reset/stash/delete is required. Scheduled bots use the checked-out folder. Do not merge main before the planned Monday check.

Reports/logs/screenshots remain under the printed `%TEMP%\cc-closed-loop-*` folder. An existing Chromium can be selected with `CC_PLAYWRIGHT_EXECUTABLE`. Cloud prerequisites: Python 3.12, Node 24, editable dev install plus pyarrow/tzdata, npm ci, and system Chromium with normal TLS. On Windows install only missing dependencies/browser using README instructions.

The original implementation review findings were corrected with regression tests: owned worker/server imports and cleanup, resolved ledger/sidecar/control aliases, conservative orphan shutdown, auth exclusion, supported-write observation and empty-data classification. Failed/unverified shutdown or handle closure preserves sandbox state. Authenticated cursor logs are suppressed. Demo-seeding guard is separate commit f3f3b97; kill_drill behavior is unchanged.

SHA256SUMS validates the included files. The ZIP contains the bundle, patch, reports, screenshots, startup diagnostics and this handoff.
