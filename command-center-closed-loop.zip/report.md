# Closed-loop report

2026-10-04 18:36:21 EDT

**1 FAIL / 7 NOT COVERED / 33 PASS**

| Check | Result | Evidence |
|---|---|---|
| Live fingerprint before | NOT COVERED | Windows live ledger not supplied; no live-record claim can be made from the cloud bundle |
| Actual fleet registration (SYNTHETIC) | PASS | 5 paper manifests registered in external sandbox |
| Real Schwab data | NOT COVERED | Injected CC_TOKEN_BROKER_URL/CC_TOKEN_BROKER_SECRET absent; no credential files read |
| Real Polygon options | NOT COVERED | Injected POLYGON_API_KEY absent; no credential files read |
| Historical replay gap_go | NOT COVERED | SPX500_USD parquet absent; bundle does not include local var/data; NAS100_USD parquet absent; bundle does not include local var/data |
| Historical replay nr7 | NOT COVERED | SPX500_USD parquet absent; bundle does not include local var/data; US2000_USD parquet absent; bundle does not include local var/data |
| Actual gap_go signal/risk/fill/exit (SYNTHETIC) | PASS | Actual GapGoRules -> risk -> paper entry/EOD exit; 1 trade(s), 2 fills |
| Actual nr7 signal/risk/fill/exit (SYNTHETIC) | PASS | Actual NR7Rules -> risk -> paper entry/EOD exit; 1 trade(s), 2 fills |
| Actual sip_orb signal/risk/fill/exit (SYNTHETIC) | PASS | Actual SipOrbRules -> risk -> paper entry/EOD exit; 1 trade(s), 2 fills |
| Daily SPY decide/reconcile (SYNTHETIC) | PASS | Actual cmd_decide/cmd_reconcile/PaperBroker: entry, 5% stop, exit_sma, persisted trade; controlled calendar |
| Daily SPY protective stop (SYNTHETIC) | PASS | Actual cmd_decide/cmd_reconcile/PaperBroker: entry, 5% stop, crash_stop, persisted trade; controlled calendar |
| Stale options chain refused (SYNTHETIC) | PASS | Actual fill model refused a 500-second-old chain; NONE decision persisted |
| Actual gap-go debit spread (SYNTHETIC) | PASS | Actual GapGoRules opened two OCC legs, qty=4; optlive Greeks persisted |
| Dashboard fleet/trades/fills (SYNTHETIC) | PASS | 5 actual bot IDs; 8 recent fills; equity trades visible on each detail API |
| Dashboard open-spread Greeks (SYNTHETIC) | PASS | Fleet/detail delta=80.00 shares; theta=0.00/day; DTE=2 |
| Dashboard bots (SYNTHETIC) | PASS | Actual API returned a valid JSON payload |
| Dashboard risk (SYNTHETIC) | PASS | Actual API returned a valid JSON payload |
| Dashboard alerts (SYNTHETIC) | PASS | Actual API returned a valid JSON payload |
| Dashboard research (SYNTHETIC) | PASS | Actual API returned a valid JSON payload |
| Dashboard health (SYNTHETIC) | PASS | Actual API returned a valid JSON payload |
| Rendered fleet screenshot (SYNTHETIC) | PASS | Actual app rendered five bots; fleet.png saved |
| Rendered spread screenshot (SYNTHETIC) | PASS | Actual spread, Greeks and DTE rendered; gap_go_spread.png saved |
| Spread flatten button (SYNTHETIC) | FAIL | Product defect: Flatten now is disabled with two open option legs (BotPage uses single-position pos) |
| Browser checks executed (SYNTHETIC) | PASS | Rendered checks reported individually |
| Oversized share order refused (SYNTHETIC) | PASS | qty=6000 rejected by max_order_qty; order id=14; Needs attention populated |
| Excessive spread premium refused (SYNTHETIC) | PASS | $1,000,000 requested premium exceeds $5,000 cap; both legs recorded rejected |
| Invalid confirmation (SYNTHETIC) | PASS | Wrong word -> HTTP 400; no flag or action audit |
| Bot pause/exit/resume (SYNTHETIC) | PASS | Runner suppressed entry; SDK recorded pause rejection; actual stop exit filled while paused; resume restored eligibility |
| Bot spread flatten (SYNTHETIC) | PASS | Confirmed API flatten -> real spread close; option_trades persisted; legs and optlive removed |
| Bot kill/resume (SYNTHETIC) | PASS | Confirmed bot kill blocked SDK entry; resume removed bot kill |
| Fleet pause/resume (SYNTHETIC) | PASS | Fleet pause refused new entry and permitted exit; resume cleared flag |
| Fleet flatten (SYNTHETIC) | PASS | Confirmed flatten_all -> next actual runner polls closed all intraday positions |
| Fleet kill/re-arm (SYNTHETIC) | PASS | Audit before KILL; all five killed; next polls flattened spread; SDK blocked entry; re-arm restored eligibility |
| Audit before server flags (SYNTHETIC) | PASS | Observed 16 actual server flag writes with matching audits already persisted |
| Scheduled/live/scanner integrations | NOT COVERED | Windows scheduler, live order path and external SIP scanner excluded; synthetic bot lifecycles are separately asserted |
| Owned sandbox server stopped | PASS | Owned server exited; no live process was stopped |
| Bot ledger handles closed | PASS | All owned bot SQLite handles closed |
| Live fingerprint after / isolation | NOT COVERED | No Windows live ledger in cloud; absent source state remained absent |
| Runtime cleanup | PASS | Sandbox ledger/control/logs removed; report/screenshots retained |
| Isolated source cleanup | PASS | Copied source and daily-bot state/logs removed |
| Filesystem write isolation | PASS | 205 supported Python filesystem/SQLite operations observed in worker/server; native-library writes are not an OS-wide trace |

## Live fingerprint

Heartbeats and kv excluded. Missing cloud state does not verify the Windows record.

### Before

```json
{
  "available": false,
  "tables": {},
  "control": [],
  "control_exists": false,
  "excluded_tables": [
    "heartbeats",
    "kv"
  ]
}
```

### After

```json
{
  "available": false,
  "tables": {},
  "control": [],
  "control_exists": false,
  "excluded_tables": [
    "heartbeats",
    "kv"
  ]
}
```

## Function reachability

Observed calls are not proof of every behavior; scenario assertions are reported above.

| Function | Observed call | Scenarios |
|---|---|---|
| bots/gap_go_bot/gap_go_rules.py:12 GapGoRules.__init__ | yes | Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Stale options chain refused |
| bots/gap_go_bot/gap_go_rules.py:15 GapGoRules.decide | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Stale options chain refused |
| bots/gap_go_spread_bot/bot.py:52 make_runner | NOT COVERED |  |
| bots/nr7_bot/nr7_rules.py:10 NR7Rules.__init__ | yes | API controls and bot response, Actual nr7 signal/risk/fill/exit |
| bots/nr7_bot/nr7_rules.py:13 NR7Rules.decide | yes | API controls and bot response, Actual nr7 signal/risk/fill/exit |
| bots/sip_orb/sip_orb_rules.py:14 SipOrbRules.__init__ | yes | API controls and bot response, Actual sip_orb signal/risk/fill/exit |
| bots/sip_orb/sip_orb_rules.py:17 SipOrbRules.decide | yes | API controls and bot response, Actual sip_orb signal/risk/fill/exit |
| bots/sip_orb/sip_scanner.py:18 filter_rank | NOT COVERED |  |
| bots/sip_orb/sip_scanner.py:34 fetch | NOT COVERED |  |
| bots/sip_orb/sip_scanner.py:45 universe | NOT COVERED |  |
| bots/spy_mr_bot/bot.py:38 _token_path | NOT COVERED |  |
| bots/spy_mr_bot/bot.py:59 load_state | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:66 save_state | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:70 make_broker | NOT COVERED |  |
| bots/spy_mr_bot/bot.py:91 trading_day_today | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:97 cmd_decide | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:165 cmd_reconcile | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:232 cmd_status | NOT COVERED |  |
| bots/spy_mr_bot/bot.py:237 cmd_check | NOT COVERED |  |
| bots/spy_mr_bot/bot.py:248 _flat | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/bot.py:252 _f | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:27 SchwabBroker.__init__ | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:39 SchwabBroker._json | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:46 SchwabBroker.daily_closes | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:57 SchwabBroker.last_price | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:62 SchwabBroker._account | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:67 SchwabBroker.position | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:73 SchwabBroker.equity | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:78 SchwabBroker._place | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:85 SchwabBroker.buy_moc | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:90 SchwabBroker.sell_moc | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:95 SchwabBroker.place_stop | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:105 SchwabBroker.cancel_open_orders | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:129 PaperBroker.__init__ | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:138 PaperBroker._save | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:142 PaperBroker.daily_closes | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:147 PaperBroker.last_price | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:153 PaperBroker.position | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:156 PaperBroker.equity | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:164 PaperBroker._queue | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:171 PaperBroker.buy_moc | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:172 PaperBroker.sell_moc | yes | Daily SPY decide/reconcile |
| bots/spy_mr_bot/broker.py:174 PaperBroker.place_stop | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:179 PaperBroker.cancel_open_orders | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:186 PaperBroker.settle_pending | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/broker.py:211 _http | NOT COVERED |  |
| bots/spy_mr_bot/broker.py:218 _stooq_daily | NOT COVERED |  |
| bots/spy_mr_bot/cc.py:46 _NullRun.decision | NOT COVERED |  |
| bots/spy_mr_bot/cc.py:47 _NullRun.order_sent | NOT COVERED |  |
| bots/spy_mr_bot/cc.py:48 _NullRun.note | NOT COVERED |  |
| bots/spy_mr_bot/cc.py:51 run | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:64 guarded | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:81 flatten_requested | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:85 clear_flatten | NOT COVERED |  |
| bots/spy_mr_bot/cc.py:90 record_fill | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:95 set_position | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:100 record_equity | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/cc.py:105 record_trade | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/dashboard.py:26 _json | NOT COVERED |  |
| bots/spy_mr_bot/dashboard.py:33 _run | NOT COVERED |  |
| bots/spy_mr_bot/dashboard.py:38 snapshot | NOT COVERED |  |
| bots/spy_mr_bot/dashboard.py:116 index | NOT COVERED |  |
| bots/spy_mr_bot/dashboard.py:121 run | NOT COVERED |  |
| bots/spy_mr_bot/dashboard.py:128 api | NOT COVERED |  |
| bots/spy_mr_bot/strategy.py:25 sma | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/strategy.py:31 rsi_wilder | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/strategy.py:59 snapshot | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/strategy.py:68 entry_signal | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| bots/spy_mr_bot/strategy.py:74 exit_signal | yes | Daily SPY decide/reconcile |
| bots/spy_mr_bot/strategy.py:83 stop_price | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:21 Run.__init__ | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:26 Run.decision | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:29 Run.order_sent | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:34 Run.order_rejected | NOT COVERED |  |
| cc_sdk/cc_sdk/__init__.py:38 Run.note | NOT COVERED |  |
| cc_sdk/cc_sdk/__init__.py:43 Bot.__init__ | yes | Register five actual manifests |
| cc_sdk/cc_sdk/__init__.py:51 Bot.run | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:67 Bot.record_fill | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:73 Bot.set_position | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:77 Bot.positions | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Stale options chain refused |
| cc_sdk/cc_sdk/__init__.py:80 Bot.record_equity | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:83 Bot.record_trade | yes | API controls and bot response, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:86 Bot.last_sent_order_id | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/__init__.py:91 Bot.now | NOT COVERED |  |
| cc_sdk/cc_sdk/control.py:12 control_dir | yes | Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/control.py:17 Control.__init__ | yes | Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/control.py:22 Control.dir_ok | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:25 Control.fleet_killed | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:28 Control.bot_killed | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:31 Control.killed | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:34 Control.entries_paused | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:37 Control.flatten_requested | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/control.py:40 Control.clear_flatten | yes | API controls and bot response |
| cc_sdk/cc_sdk/control.py:45 Control.status_word | yes | Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/control.py:53 Control.write_flag | yes | Sandbox API/riskd |
| cc_sdk/cc_sdk/control.py:59 Control.pause_bot | NOT COVERED |  |
| cc_sdk/cc_sdk/control.py:62 Control.read_flag | yes | Sandbox API/riskd |
| cc_sdk/cc_sdk/intraday.py:36 Bar.mod | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:60 Signal.resolve | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:71 Rules.decide | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:76 Feed.minute_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:77 Feed.quote | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:79 Feed.daily_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:82 day_context | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:92 size_by_risk | yes | API controls and bot response, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit |
| cc_sdk/cc_sdk/intraday.py:116 SessionRunner.__init__ | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:133 SessionRunner.prepare | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:149 SessionRunner.step | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Stale options chain refused |
| cc_sdk/cc_sdk/intraday.py:192 SessionRunner.loop | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:208 SessionRunner._enter | yes | API controls and bot response, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit |
| cc_sdk/cc_sdk/intraday.py:232 SessionRunner._exit | yes | API controls and bot response, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit |
| cc_sdk/cc_sdk/intraday.py:252 ReplayFeed.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:256 ReplayFeed.minute_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:260 ReplayFeed.quote | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:268 ReplayFeed.daily_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday.py:272 minutes_of | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday_cli.py:18 replay_feed | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday_cli.py:33 run_replay | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday_cli.py:63 replay_isolated | NOT COVERED |  |
| cc_sdk/cc_sdk/intraday_cli.py:75 main | NOT COVERED |  |
| cc_sdk/cc_sdk/ledger.py:18 set_clock | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Bot ledger handles closed, Daily SPY decide/reconcile, Daily SPY protective stop, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:24 now | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:28 now_iso | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:32 var_dir | yes | Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:44 token_path | NOT COVERED |  |
| cc_sdk/cc_sdk/ledger.py:55 db_path | yes | Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:60 Ledger.__init__ | yes | Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:68 Ledger.q | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:71 Ledger.one | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:74 Ledger.x | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, SDK risk refusals, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:79 Ledger.upsert_bot | yes | Register five actual manifests |
| cc_sdk/cc_sdk/ledger.py:90 Ledger.set_bot_status | yes | Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:94 Ledger.heartbeat | yes | Daily SPY decide/reconcile, Daily SPY protective stop, Register five actual manifests |
| cc_sdk/cc_sdk/ledger.py:98 Ledger.decision | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:102 Ledger.order | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/ledger.py:111 Ledger.fill | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/ledger.py:117 Ledger.set_position | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/ledger.py:130 Ledger.positions_for | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:134 Ledger._migrate_positions | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd, Stale options chain refused |
| cc_sdk/cc_sdk/ledger.py:150 Ledger.equity | yes | Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/ledger.py:153 Ledger.trade | yes | API controls and bot response, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop |
| cc_sdk/cc_sdk/ledger.py:159 Ledger.alert | yes | API controls and bot response, SDK risk refusals, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:163 Ledger.control | yes | Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:168 Ledger.limit | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:172 Ledger.set_limit | NOT COVERED |  |
| cc_sdk/cc_sdk/ledger.py:177 Ledger.latest_broker_equity_total | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:187 Ledger.gross_exposure_usd | yes | Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:194 Ledger.orders_today | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:201 Ledger.recent_trades | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd |
| cc_sdk/cc_sdk/ledger.py:204 Ledger.bot_peak_and_last_equity | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, Sandbox API/riskd |
| cc_sdk/cc_sdk/manifest.py:44 BotManifest.__post_init__ | yes | Register five actual manifests |
| cc_sdk/cc_sdk/manifest.py:56 BotManifest.to_row | yes | Register five actual manifests |
| cc_sdk/cc_sdk/options.py:18 is_occ | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals, Sandbox API/riskd |
| cc_sdk/cc_sdk/options.py:22 contract_multiplier | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals, Sandbox API/riskd |
| cc_sdk/cc_sdk/options.py:27 occ_symbol | yes | API controls and bot response, Actual gap-go debit spread, SDK risk refusals, Stale options chain refused |
| cc_sdk/cc_sdk/options.py:34 parse_occ | NOT COVERED |  |
| cc_sdk/cc_sdk/options.py:43 intrinsic | NOT COVERED |  |
| cc_sdk/cc_sdk/options.py:67 OptionQuote.mid | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options.py:71 OptionQuote.spread | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options.py:76 _num | NOT COVERED |  |
| cc_sdk/cc_sdk/options.py:87 parse_schwab_chain | NOT COVERED |  |
| cc_sdk/cc_sdk/options.py:111 now_epoch | NOT COVERED |  |
| cc_sdk/cc_sdk/options.py:121 paper_fill_price | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options.py:147 fill_spread | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options.py:159 spread_pnl | yes | API controls and bot response |
| cc_sdk/cc_sdk/options_report.py:16 _pf | NOT COVERED |  |
| cc_sdk/cc_sdk/options_report.py:24 options_report | NOT COVERED |  |
| cc_sdk/cc_sdk/options_runner.py:27 ChainFeed.chain | NOT COVERED |  |
| cc_sdk/cc_sdk/options_runner.py:41 pick_vertical | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:62 SpreadSessionRunner.__init__ | yes | Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:70 SpreadSessionRunner._kv_key | yes | API controls and bot response, Actual gap-go debit spread |
| cc_sdk/cc_sdk/options_runner.py:74 SpreadSessionRunner._live_key | yes | API controls and bot response, Actual gap-go debit spread |
| cc_sdk/cc_sdk/options_runner.py:77 SpreadSessionRunner._record_live | yes | API controls and bot response, Actual gap-go debit spread |
| cc_sdk/cc_sdk/options_runner.py:94 SpreadSessionRunner._refresh_live | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:105 SpreadSessionRunner.step | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:109 SpreadSessionRunner.prepare | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:124 SpreadSessionRunner._now | yes | API controls and bot response |
| cc_sdk/cc_sdk/options_runner.py:128 SpreadSessionRunner._none | yes | Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:133 SpreadSessionRunner._enter | yes | API controls and bot response, Actual gap-go debit spread, Stale options chain refused |
| cc_sdk/cc_sdk/options_runner.py:181 SpreadSessionRunner._exit | yes | API controls and bot response |
| cc_sdk/cc_sdk/polygon_options.py:28 _f | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:36 parse_polygon_snapshot | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:59 PolygonOptions.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:66 PolygonOptions.snapshot | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:93 polygon_from_env | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:100 MixedFeed.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:103 MixedFeed.quote | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:106 MixedFeed.minute_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:109 MixedFeed.daily_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:112 MixedFeed.check | NOT COVERED |  |
| cc_sdk/cc_sdk/polygon_options.py:115 MixedFeed.chain | NOT COVERED |  |
| cc_sdk/cc_sdk/risk.py:36 RiskResult.to_dict | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:41 Risk.__init__ | yes | Register five actual manifests |
| cc_sdk/cc_sdk/risk.py:46 Risk._lim | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:49 Risk._plim | NOT COVERED |  |
| cc_sdk/cc_sdk/risk.py:52 Risk.pre_trade | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:55 Risk.pre_trade.fail | yes | API controls and bot response, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:61 Risk.pre_trade.passed | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:157 Risk.pre_trade_spread | yes | API controls and bot response, Actual gap-go debit spread, SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:171 Risk.pre_trade_spread.reject_all | yes | SDK risk refusals |
| cc_sdk/cc_sdk/risk.py:196 Risk._record | yes | API controls and bot response, Actual gap-go debit spread, Actual gap_go signal/risk/fill/exit, Actual nr7 signal/risk/fill/exit, Actual sip_orb signal/risk/fill/exit, Daily SPY decide/reconcile, Daily SPY protective stop, SDK risk refusals |
| cc_sdk/cc_sdk/schwab_feed.py:50 _BrokerSession.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:62 _BrokerSession._needs_token | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:65 _BrokerSession._fetch_token | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:89 _BrokerSession.access_token | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:97 _BrokerSession._invalidate | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:102 _BrokerSession._get | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:110 _BrokerSession.get_quote | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:113 _BrokerSession.get_price_history_every_minute | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:120 _BrokerSession.get_price_history_every_day | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:127 _BrokerSession.get_option_chain | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:149 _SharedStateSession.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:159 _SharedStateSession._read_state | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:169 _SharedStateSession._fetch_token | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:200 _SharedStateSession._write_back | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:217 _ms | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:223 _parse_iso | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:233 SchwabFeed.__init__ | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:237 SchwabFeed.from_broker | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:251 SchwabFeed.connect | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:269 SchwabFeed.check | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:279 SchwabFeed._bars | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:287 SchwabFeed.minute_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:300 SchwabFeed.quote | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:307 SchwabFeed.chain | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:315 SchwabFeed.daily_bars | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:323 write_issued_sidecar | NOT COVERED |  |
| cc_sdk/cc_sdk/schwab_feed.py:331 issued_at_utc | NOT COVERED |  |
| cc_server/cc_server/alerts.py:20 Channel.send | NOT COVERED |  |
| cc_server/cc_server/alerts.py:25 Console.send | NOT COVERED |  |
| cc_server/cc_server/alerts.py:33 Sms.__init__ | NOT COVERED |  |
| cc_server/cc_server/alerts.py:38 Sms.send | NOT COVERED |  |
| cc_server/cc_server/alerts.py:50 Email.__init__ | NOT COVERED |  |
| cc_server/cc_server/alerts.py:54 Email.send | NOT COVERED |  |
| cc_server/cc_server/alerts.py:61 load_config | yes | Sandbox API/riskd |
| cc_server/cc_server/alerts.py:68 build | yes | Sandbox API/riskd |
| cc_server/cc_server/alerts.py:78 Alerter.__init__ | yes | Sandbox API/riskd |
| cc_server/cc_server/alerts.py:84 Alerter.deliver_pending_pages | yes | Sandbox API/riskd |
| cc_server/cc_server/alerts.py:97 Alerter.send_digest | NOT COVERED |  |
| cc_server/cc_server/alerts.py:110 Alerter.test | NOT COVERED |  |
| cc_server/cc_server/alerts.py:122 write_default_config | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:31 L | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:38 alerter | NOT COVERED |  |
| cc_server/cc_server/api.py:45 _bot_summary | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:71 _sort_key | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:78 fleet | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:112 bots | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:118 bot | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:148 risk | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:180 alerts | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:185 ack | NOT COVERED |  |
| cc_server/cc_server/api.py:191 alert_test | NOT COVERED |  |
| cc_server/cc_server/api.py:196 research | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:211 health | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:216 db_path_safe | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:227 get_confirm_word | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:234 _check_word | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:240 _trigger_reconcile | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:252 kill_all | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:266 flatten_all | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:279 pause_entries | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:287 resume_entries | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:296 rearm | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:305 bot_control | yes | Sandbox API/riskd |
| cc_server/cc_server/api.py:338 _run_bot_cmd | NOT COVERED |  |
| cc_server/cc_server/api.py:358 set_limit | NOT COVERED |  |
| cc_server/cc_server/calendar.py:25 is_trading_day | yes | Sandbox API/riskd |
| cc_server/cc_server/calendar.py:29 is_early_close | yes | Sandbox API/riskd |
| cc_server/cc_server/calendar.py:33 next_trading_day | NOT COVERED |  |
| cc_server/cc_server/calendar.py:40 next_early_close | yes | Sandbox API/riskd |
| cc_server/cc_server/calendar.py:45 close_time_str | NOT COVERED |  |
| cc_server/cc_server/calendar.py:49 decide_time_str | NOT COVERED |  |
| cc_server/cc_server/db.py:13 rows | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:17 bot_rows | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:27 last_heartbeat | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:32 positions | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:36 position | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:42 equity_series | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:48 broker_equity_series | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:54 trades | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:58 decisions | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:65 fills | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:75 open_orders | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:80 alerts | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:88 controls | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:96 limits | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:100 rejected_orders_24h | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:106 kv_get | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:111 kv_prefix | yes | Sandbox API/riskd |
| cc_server/cc_server/db.py:117 kv_set | yes | Sandbox API/riskd |
| cc_server/cc_server/main.py:23 setup_logging | yes | Sandbox API/riskd |
| cc_server/cc_server/main.py:30 riskd_loop | yes | Sandbox API/riskd |
| cc_server/cc_server/main.py:44 lifespan | yes | Sandbox API/riskd |
| cc_server/cc_server/main.py:62 spa | yes | Sandbox API/riskd |
| cc_server/cc_server/parity.py:9 win_rate_band | yes | Sandbox API/riskd |
| cc_server/cc_server/parity.py:17 evaluate | yes | Sandbox API/riskd |
| cc_server/cc_server/parity.py:63 expected_path | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:33 plim | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:38 portfolio_drawdown | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:47 day_pnl | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:58 gross_exposure | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:64 correlation | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:100 most_correlated_pair | NOT COVERED |  |
| cc_server/cc_server/riskd.py:111 apply_ladder | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:143 heartbeat_watch | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:182 token_days_left | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:208 token_watch | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:217 early_close_notice | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:227 parity_all | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:239 bot_status | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:252 tick | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:272 rearm | yes | Sandbox API/riskd |
| cc_server/cc_server/riskd.py:281 today_is_trading | NOT COVERED |  |
| cc_server/cc_server/riskd.py:285 host_info | yes | Sandbox API/riskd |
