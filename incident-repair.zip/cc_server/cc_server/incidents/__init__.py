"""Operational incident handling, independent of trading state and risk controls."""
