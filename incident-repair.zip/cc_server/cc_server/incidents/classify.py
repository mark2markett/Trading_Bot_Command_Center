"""Fixed classifications; alert prose is untrusted and never drives an action."""

from datetime import timezone
from zoneinfo import ZoneInfo

from .models import BOT_IDS, Observation, parsed

KINDS = {
    "run_failed": "run_failed",
    "heartbeat": "heartbeat",
    "token": "token",
    "order_rejected": "order_rejected",
    "calendar": "calendar",
    "parity": "parity",
    "position_mismatch": "position_mismatch",
    "ladder_pause": "risk_control",
    "ladder_flatten": "risk_control",
    "ladder_kill": "risk_control",
    "auto_pause": "risk_control",
}


def classify_alert(row, *, historical):
    condition = KINDS.get(row.get("kind"), "unknown_alert")
    at = parsed(str(row["at"]))
    bot = row.get("bot_id")
    scope = bot if bot in BOT_IDS else "fleet"
    date = None if condition == "token" else at.astimezone(ZoneInfo("America/New_York")).date().isoformat()
    return Observation(
        condition,
        scope,
        date,
        row.get("severity") if row.get("severity") in {"page", "digest", "info"} else "page",
        "historical" if historical else "unknown",
        at.astimezone(timezone.utc).isoformat(),
        {"alert_id": int(row["id"])},
        (int(row["id"]),),
    )
