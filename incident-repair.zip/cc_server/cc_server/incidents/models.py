from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

RECOVERABLE = {"server_health", "local_read", "platform_health", "heartbeat", "daily_context", "token", "sip_opening", "valuation"}
BOT_IDS = {"sip_orb", "gap_go", "gap_go_spread", "nr7", "spy_mr"}


def iso(at: datetime) -> str:
    if at.tzinfo is None:
        raise ValueError("Aware timestamp required")
    return at.astimezone(timezone.utc).isoformat()


def parsed(value: str) -> datetime:
    at = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if at.tzinfo is None:
        raise ValueError("Aware timestamp required")
    return at


@dataclass(frozen=True)
class Observation:
    condition: str
    scope: str
    session_date: str | None
    severity: str
    verdict: str
    at: str
    evidence: dict[str, Any] = field(default_factory=dict)
    source_ids: tuple[int, ...] = ()


@dataclass(frozen=True)
class ActionClaim:
    id: int
    incident_id: int
    action: str
    reserved_at: str
    expires_at: str


@dataclass(frozen=True)
class TickResult:
    complete: bool
    counts: dict[str, int]
    action_claims: list[ActionClaim]
    errors: list[str]
    at: str
