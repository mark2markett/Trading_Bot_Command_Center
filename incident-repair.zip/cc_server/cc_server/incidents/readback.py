"""Read-only dashboard projection; failure never masquerades as an empty healthy feed."""

import json
import sqlite3
from contextlib import closing
from pathlib import Path

from .models import parsed
from .observe import identity, readonly
from .store import NEXT


def legacy_run_failure(runtime_dir, item, ledger_identity):
    """Explain old classifications using typed source kinds, never alert prose."""
    ids = item["source_ids"]
    if item["condition"] != "unknown_alert" or not ids or len(ids) > 1000:
        return
    ledger = Path(runtime_dir) / "cc.db"
    try:
        if identity(ledger) != ledger_identity:
            return
        with closing(readonly(ledger)) as db:
            rows = db.execute("SELECT id,kind FROM alerts WHERE id IN (" + ",".join("?" for _ in ids) + ")", ids).fetchall()
        if identity(ledger) == ledger_identity and len(rows) == len(ids) and all(row["kind"] == "run_failed" for row in rows):
            item["condition"] = "run_failed"
            item["next_step"] = NEXT["run_failed"]
    except (OSError, sqlite3.Error, ValueError):
        # Missing source evidence must not hide or resolve an existing incident.
        return


def read_incidents(runtime_dir, *, now, limit=100, after=0):
    root = Path(runtime_dir) / "monitor"
    path = root / "incidents.db"
    result = {
        "monitor": {
            "status": "unavailable",
            "last_completed_at": None,
            "recovery_enabled": False,
            "notification_status": "unknown",
            "errors": [],
        },
        "open": [],
        "recent_resolved": [],
        "open_count": None,
        "next_after": None,
        "linked_source_ids": [],
    }
    if not path.exists():
        if not (root / "installed.json").exists():
            result["monitor"]["status"] = "not_installed"
        return result
    if path.is_symlink():
        return result
    try:
        with closing(readonly(path)) as db:
            db.execute("BEGIN")
            if db.execute("PRAGMA user_version").fetchone()[0] != 1:
                return result

            def state(key, default=None):
                row = db.execute("SELECT value_json FROM worker_state WHERE key=?", (key,)).fetchone()
                return json.loads(row[0]) if row else default

            tick = state("last_tick")
            if not isinstance(tick, dict):
                return result
            age = (now - parsed(tick["at"])).total_seconds()
            status = "unavailable" if age < 0 or tick.get("errors") else "overdue" if age > 180 else "checking"
            attempt = root / "latest.json"
            if attempt.exists():
                recent = json.loads(attempt.read_text())
                if parsed(recent["at"]) >= parsed(tick["at"]) and recent.get("complete") is not True:
                    status = "unavailable"
            monitor = result["monitor"]
            monitor.update(
                status=status,
                last_completed_at=tick["at"],
                recovery_enabled=state("recovery_enabled", False),
                notification_status=state("notification_status", "unknown"),
                errors=tick.get("errors", []),
            )
            monitor["notification_failures"] = db.execute(
                "SELECT count(*) FROM notification_outbox WHERE state IN ('failed','uncertain','retry')"
            ).fetchone()[0]

            def entry(row):
                item = dict(row)
                item.pop("key", None)
                item["evidence"] = json.loads(item.pop("evidence_json"))
                item["source_ids"] = [
                    r[0]
                    for r in db.execute(
                        "SELECT alert_id FROM incident_sources WHERE incident_id=? AND ledger_id=?",
                        (item["id"], str(state("ledger_identity", "unbound")) + ":" + str(state("generation", 0))),
                    )
                ]
                legacy_run_failure(runtime_dir, item, state("ledger_identity"))
                return item

            size = min(250, max(1, limit))
            rows = db.execute(
                "SELECT * FROM incidents WHERE state<>'resolved' AND id>? ORDER BY id LIMIT ?", (after, size + 1)
            ).fetchall()
            result["open"] = [entry(row) for row in rows[:size]]
            if len(rows) > size:
                result["next_after"] = rows[size - 1]["id"]
            result["open_count"] = db.execute("SELECT count(*) FROM incidents WHERE state<>'resolved'").fetchone()[0]
            result["recent_resolved"] = [
                entry(r) for r in db.execute("SELECT * FROM incidents WHERE state='resolved' ORDER BY last_at DESC LIMIT 20")
            ]
            # Link only returned items; a source whose case is on a later page remains visible.
            result["linked_source_ids"] = list(
                {source for item in result["open"] + result["recent_resolved"] for source in item["source_ids"]}
            )
    except (OSError, sqlite3.Error, ValueError, KeyError, TypeError):
        result["monitor"]["status"] = "unavailable"
        result["open_count"] = None
    return result
